export interface Product {
  id: string;
  name: string;
  slug: string;
  category: string;
  subcategory?: string;
  description: string;
  shortDescription: string;
  features: string[];
  images: string[];
  variants: ProductVariant[];
  rating: number;
  reviewCount: number;
  isNew?: boolean;
  isBestseller?: boolean;
  isOnSale?: boolean;
}

export interface ProductVariant {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  size?: string;
  color?: string;
  material?: string;
  firmness?: string;
  inStock: boolean;
  sku: string;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  coverImage: string;
  category: string;
  author: string;
  authorImage?: string;
  publishDate: string;
  readTime: number;
}

export interface Testimonial {
  id: string;
  name: string;
  image?: string;
  rating: number;
  text: string;
  product?: string;
  date: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  image: string;
  featuredProducts: string[];
}