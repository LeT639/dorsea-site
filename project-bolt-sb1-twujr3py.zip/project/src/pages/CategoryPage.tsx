import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import ProductGrid from '../components/products/ProductGrid';
import { getProductsByCategory } from '../data/products';
import { getCategory } from '../data/categories';
import { Product } from '../types';
import { Filter, SlidersHorizontal, X } from 'lucide-react';

const CategoryPage: React.FC = () => {
  const { categoryId } = useParams<{ categoryId: string }>();
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  
  const [filters, setFilters] = useState({
    priceRange: { min: 0, max: 2000 },
    onSale: false,
    inStock: false,
    sortBy: 'featured', // featured, price-asc, price-desc, newest
  });

  const category = categoryId ? getCategory(categoryId) : undefined;

  useEffect(() => {
    if (categoryId) {
      const categoryProducts = getProductsByCategory(categoryId);
      setProducts(categoryProducts);
      setFilteredProducts(categoryProducts);
    }
  }, [categoryId]);

  useEffect(() => {
    applyFilters();
  }, [filters, products]);

  const applyFilters = () => {
    let result = [...products];

    // Filter by price range
    result = result.filter(product => {
      const cheapestVariant = product.variants.reduce((min, variant) => 
        variant.price < min.price ? variant : min, product.variants[0]);
      return cheapestVariant.price >= filters.priceRange.min && 
             cheapestVariant.price <= filters.priceRange.max;
    });

    // Filter on sale items
    if (filters.onSale) {
      result = result.filter(product => product.isOnSale);
    }

    // Filter in stock items
    if (filters.inStock) {
      result = result.filter(product => 
        product.variants.some(variant => variant.inStock)
      );
    }

    // Sort products
    switch (filters.sortBy) {
      case 'price-asc':
        result.sort((a, b) => {
          const aPrice = a.variants.reduce((min, variant) => 
            variant.price < min ? variant.price : min, a.variants[0].price);
          const bPrice = b.variants.reduce((min, variant) => 
            variant.price < min ? variant.price : min, b.variants[0].price);
          return aPrice - bPrice;
        });
        break;
      case 'price-desc':
        result.sort((a, b) => {
          const aPrice = a.variants.reduce((min, variant) => 
            variant.price < min ? variant.price : min, a.variants[0].price);
          const bPrice = b.variants.reduce((min, variant) => 
            variant.price < min ? variant.price : min, b.variants[0].price);
          return bPrice - aPrice;
        });
        break;
      // Additional sort options could be added here
      default:
        // Default to featured (no change to order)
        break;
    }

    setFilteredProducts(result);
  };

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFilters(prev => ({ ...prev, sortBy: e.target.value }));
  };

  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'min' | 'max') => {
    const value = parseInt(e.target.value);
    setFilters(prev => ({
      ...prev,
      priceRange: {
        ...prev.priceRange,
        [type]: value
      }
    }));
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: checked
    }));
  };

  const toggleFilters = () => {
    setIsFilterOpen(!isFilterOpen);
  };

  if (!category) {
    return <div className="container mx-auto px-4 py-16">Category not found</div>;
  }

  return (
    <div className="pt-24 pb-16">
      <div className="bg-[#F5F2EA] py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-semibold text-gray-800 mb-4">{category.name}</h1>
          <p className="text-gray-600 max-w-3xl">{category.description}</p>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filter Button (Mobile) */}
          <div className="lg:hidden">
            <button
              onClick={toggleFilters}
              className="w-full flex items-center justify-center gap-2 bg-white border border-gray-300 px-4 py-2 rounded-md text-gray-700 hover:bg-gray-50"
            >
              <Filter size={18} />
              <span>Filter & Sort</span>
            </button>
          </div>
          
          {/* Filters (Desktop) */}
          <aside className="hidden lg:block lg:w-64 space-y-6">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <SlidersHorizontal size={18} className="mr-2" /> Filters
              </h3>
              
              <div className="space-y-6">
                {/* Price Range */}
                <div>
                  <h4 className="font-medium text-gray-700 mb-3">Price Range</h4>
                  <div className="flex flex-col space-y-2">
                    <label className="text-sm text-gray-600">Min Price: €{filters.priceRange.min}</label>
                    <input
                      type="range"
                      min="0"
                      max="2000"
                      step="100"
                      value={filters.priceRange.min}
                      onChange={(e) => handlePriceChange(e, 'min')}
                      className="w-full"
                    />
                  </div>
                  <div className="flex flex-col space-y-2 mt-3">
                    <label className="text-sm text-gray-600">Max Price: €{filters.priceRange.max}</label>
                    <input
                      type="range"
                      min="0"
                      max="2000"
                      step="100"
                      value={filters.priceRange.max}
                      onChange={(e) => handlePriceChange(e, 'max')}
                      className="w-full"
                    />
                  </div>
                </div>
                
                {/* Availability */}
                <div>
                  <h4 className="font-medium text-gray-700 mb-3">Availability</h4>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="inStock"
                        name="inStock"
                        checked={filters.inStock}
                        onChange={handleCheckboxChange}
                        className="h-4 w-4 text-[#A7C4E2] focus:ring-[#A7C4E2]"
                      />
                      <label htmlFor="inStock" className="ml-2 text-gray-600">
                        In Stock Only
                      </label>
                    </div>
                    
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="onSale"
                        name="onSale"
                        checked={filters.onSale}
                        onChange={handleCheckboxChange}
                        className="h-4 w-4 text-[#A7C4E2] focus:ring-[#A7C4E2]"
                      />
                      <label htmlFor="onSale" className="ml-2 text-gray-600">
                        On Sale
                      </label>
                    </div>
                  </div>
                </div>
                
                {/* Sort By */}
                <div>
                  <h4 className="font-medium text-gray-700 mb-3">Sort By</h4>
                  <select
                    value={filters.sortBy}
                    onChange={handleSortChange}
                    className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A7C4E2] focus:border-transparent"
                  >
                    <option value="featured">Featured</option>
                    <option value="price-asc">Price: Low to High</option>
                    <option value="price-desc">Price: High to Low</option>
                  </select>
                </div>
              </div>
            </div>
          </aside>
          
          {/* Mobile Filters Modal */}
          {isFilterOpen && (
            <div className="fixed inset-0 bg-black bg-opacity-50 z-50 lg:hidden">
              <div className="bg-white h-full w-full max-w-md ml-auto flex flex-col">
                <div className="flex items-center justify-between p-4 border-b">
                  <h3 className="text-lg font-semibold">Filters & Sorting</h3>
                  <button 
                    onClick={toggleFilters}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    <X size={24} />
                  </button>
                </div>
                
                <div className="flex-1 overflow-y-auto p-4 space-y-6">
                  {/* Price Range */}
                  <div>
                    <h4 className="font-medium text-gray-700 mb-3">Price Range</h4>
                    <div className="flex flex-col space-y-2">
                      <label className="text-sm text-gray-600">Min Price: €{filters.priceRange.min}</label>
                      <input
                        type="range"
                        min="0"
                        max="2000"
                        step="100"
                        value={filters.priceRange.min}
                        onChange={(e) => handlePriceChange(e, 'min')}
                        className="w-full"
                      />
                    </div>
                    <div className="flex flex-col space-y-2 mt-3">
                      <label className="text-sm text-gray-600">Max Price: €{filters.priceRange.max}</label>
                      <input
                        type="range"
                        min="0"
                        max="2000"
                        step="100"
                        value={filters.priceRange.max}
                        onChange={(e) => handlePriceChange(e, 'max')}
                        className="w-full"
                      />
                    </div>
                  </div>
                  
                  {/* Availability */}
                  <div>
                    <h4 className="font-medium text-gray-700 mb-3">Availability</h4>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id="inStock-mobile"
                          name="inStock"
                          checked={filters.inStock}
                          onChange={handleCheckboxChange}
                          className="h-4 w-4 text-[#A7C4E2] focus:ring-[#A7C4E2]"
                        />
                        <label htmlFor="inStock-mobile" className="ml-2 text-gray-600">
                          In Stock Only
                        </label>
                      </div>
                      
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id="onSale-mobile"
                          name="onSale"
                          checked={filters.onSale}
                          onChange={handleCheckboxChange}
                          className="h-4 w-4 text-[#A7C4E2] focus:ring-[#A7C4E2]"
                        />
                        <label htmlFor="onSale-mobile" className="ml-2 text-gray-600">
                          On Sale
                        </label>
                      </div>
                    </div>
                  </div>
                  
                  {/* Sort By */}
                  <div>
                    <h4 className="font-medium text-gray-700 mb-3">Sort By</h4>
                    <select
                      value={filters.sortBy}
                      onChange={handleSortChange}
                      className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A7C4E2] focus:border-transparent"
                    >
                      <option value="featured">Featured</option>
                      <option value="price-asc">Price: Low to High</option>
                      <option value="price-desc">Price: High to Low</option>
                    </select>
                  </div>
                </div>
                
                <div className="p-4 border-t">
                  <button 
                    onClick={toggleFilters}
                    className="w-full bg-[#A7C4E2] hover:bg-[#8CAFD6] text-white py-2 rounded-md transition-colors"
                  >
                    Apply Filters
                  </button>
                </div>
              </div>
            </div>
          )}
          
          {/* Product Grid */}
          <div className="flex-1">
            {/* Sort Dropdown (Desktop) */}
            <div className="hidden lg:flex justify-end mb-6">
              <div className="flex items-center space-x-2">
                <span className="text-gray-600">Sort by:</span>
                <select
                  value={filters.sortBy}
                  onChange={handleSortChange}
                  className="p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A7C4E2] focus:border-transparent"
                >
                  <option value="featured">Featured</option>
                  <option value="price-asc">Price: Low to High</option>
                  <option value="price-desc">Price: High to Low</option>
                </select>
              </div>
            </div>
            
            {filteredProducts.length > 0 ? (
              <ProductGrid products={filteredProducts} />
            ) : (
              <div className="text-center py-12">
                <h3 className="text-xl font-semibold text-gray-800 mb-2">No products found</h3>
                <p className="text-gray-600">Try adjusting your filters to find what you're looking for.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategoryPage;