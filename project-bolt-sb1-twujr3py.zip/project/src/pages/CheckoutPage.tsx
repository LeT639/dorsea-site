import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { ChevronLeft, CreditCard, ShieldCheck, CheckCircle } from 'lucide-react';

type CheckoutStep = 'shipping' | 'payment' | 'review' | 'confirmation';

const CheckoutPage: React.FC = () => {
  const { items, getCartTotal } = useCart();
  const [currentStep, setCurrentStep] = useState<CheckoutStep>('shipping');
  
  const total = getCartTotal();
  const shipping = total >= 500 ? 0 : 35;
  const tax = total * 0.2;
  const grandTotal = total + shipping;
  
  const [shippingInfo, setShippingInfo] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    postalCode: '',
    country: 'France',
  });
  
  const [paymentInfo, setPaymentInfo] = useState({
    cardNumber: '',
    cardName: '',
    expiry: '',
    cvv: '',
  });
  
  const handleShippingChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setShippingInfo(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handlePaymentChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPaymentInfo(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentStep('payment');
  };
  
  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentStep('review');
  };
  
  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentStep('confirmation');
  };
  
  if (items.length === 0) {
    return (
      <div className="pt-24 pb-16">
        <div className="container mx-auto px-4 py-8 text-center">
          <h1 className="text-3xl font-semibold text-gray-800 mb-4">Votre panier est vide</h1>
          <p className="text-gray-600 mb-8">
            Vous devez ajouter des articles à votre panier avant de passer commande.
          </p>
          <Link 
            to="/"
            className="inline-block px-6 py-3 bg-[#A7C4E2] hover:bg-[#8CAFD6] text-white font-semibold rounded-md transition-colors"
          >
            Continuer mes achats
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-4 py-8">
        <Link 
          to="/cart"
          className="flex items-center text-gray-600 hover:text-[#A7C4E2] transition-colors mb-8"
        >
          <ChevronLeft size={16} className="mr-1" />
          Retour au panier
        </Link>
        
        <h1 className="text-3xl font-semibold text-gray-800 mb-8">Commande</h1>
        
        <div className="mb-12">
          <div className="flex items-center justify-between max-w-3xl mx-auto">
            <div className="flex flex-col items-center">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                currentStep === 'shipping' ? 'bg-[#A7C4E2] text-white' : 
                currentStep === 'payment' || currentStep === 'review' || currentStep === 'confirmation' ? 'bg-green-500 text-white' : 
                'bg-gray-200 text-gray-500'
              }`}>
                {currentStep === 'payment' || currentStep === 'review' || currentStep === 'confirmation' ? 
                  <CheckCircle size={20} /> : '1'}
              </div>
              <span className={`mt-2 text-sm ${
                currentStep === 'shipping' ? 'text-[#A7C4E2] font-medium' : 
                currentStep === 'payment' || currentStep === 'review' || currentStep === 'confirmation' ? 'text-green-500 font-medium' : 
                'text-gray-500'
              }`}>Livraison</span>
            </div>
            
            <div className={`flex-1 h-1 mx-2 ${
              currentStep === 'payment' || currentStep === 'review' || currentStep === 'confirmation' ? 'bg-green-500' : 'bg-gray-200'
            }`}></div>
            
            <div className="flex flex-col items-center">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                currentStep === 'payment' ? 'bg-[#A7C4E2] text-white' : 
                currentStep === 'review' || currentStep === 'confirmation' ? 'bg-green-500 text-white' : 
                'bg-gray-200 text-gray-500'
              }`}>
                {currentStep === 'review' || currentStep === 'confirmation' ? 
                  <CheckCircle size={20} /> : '2'}
              </div>
              <span className={`mt-2 text-sm ${
                currentStep === 'payment' ? 'text-[#A7C4E2] font-medium' : 
                currentStep === 'review' || currentStep === 'confirmation' ? 'text-green-500 font-medium' : 
                'text-gray-500'
              }`}>Paiement</span>
            </div>
            
            <div className={`flex-1 h-1 mx-2 ${
              currentStep === 'review' || currentStep === 'confirmation' ? 'bg-green-500' : 'bg-gray-200'
            }`}></div>
            
            <div className="flex flex-col items-center">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                currentStep === 'review' ? 'bg-[#A7C4E2] text-white' : 
                currentStep === 'confirmation' ? 'bg-green-500 text-white' : 
                'bg-gray-200 text-gray-500'
              }`}>
                {currentStep === 'confirmation' ? 
                  <CheckCircle size={20} /> : '3'}
              </div>
              <span className={`mt-2 text-sm ${
                currentStep === 'review' ? 'text-[#A7C4E2] font-medium' : 
                currentStep === 'confirmation' ? 'text-green-500 font-medium' : 
                'text-gray-500'
              }`}>Validation</span>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2">
            {currentStep === 'shipping' && (
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-6">Informations de livraison</h2>
                <form onSubmit={handleShippingSubmit}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                        Prénom *
                      </label>
                      <input
                        type="text"
                        id="firstName"
                        name="firstName"
                        value={shippingInfo.firstName}
                        onChange={handleShippingChange}
                        required
                        className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A7C4E2] focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
                        Nom *
                      </label>
                      <input
                        type="text"
                        id="lastName"
                        name="lastName"
                        value={shippingInfo.lastName}
                        onChange={handleShippingChange}
                        required
                        className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A7C4E2] focus:border-transparent"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                        Email *
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={shippingInfo.email}
                        onChange={handleShippingChange}
                        required
                        className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A7C4E2] focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                        Téléphone *
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={shippingInfo.phone}
                        onChange={handleShippingChange}
                        required
                        className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A7C4E2] focus:border-transparent"
                      />
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
                      Adresse *
                    </label>
                    <input
                      type="text"
                      id="address"
                      name="address"
                      value={shippingInfo.address}
                      onChange={handleShippingChange}
                      required
                      className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A7C4E2] focus:border-transparent"
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div>
                      <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-1">
                        Ville *
                      </label>
                      <input
                        type="text"
                        id="city"
                        name="city"
                        value={shippingInfo.city}
                        onChange={handleShippingChange}
                        required
                        className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A7C4E2] focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label htmlFor="postalCode" className="block text-sm font-medium text-gray-700 mb-1">
                        Code postal *
                      </label>
                      <input
                        type="text"
                        id="postalCode"
                        name="postalCode"
                        value={shippingInfo.postalCode}
                        onChange={handleShippingChange}
                        required
                        className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A7C4E2] focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label htmlFor="country" className="block text-sm font-medium text-gray-700 mb-1">
                        Pays *
                      </label>
                      <select
                        id="country"
                        name="country"
                        value={shippingInfo.country}
                        onChange={handleShippingChange}
                        required
                        className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A7C4E2] focus:border-transparent"
                      >
                        <option value="France">France</option>
                        <option value="Belgique">Belgique</option>
                        <option value="Suisse">Suisse</option>
                        <option value="Luxembourg">Luxembourg</option>
                        <option value="Monaco">Monaco</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      className="px-6 py-3 bg-[#A7C4E2] hover:bg-[#8CAFD6] text-white font-semibold rounded-md transition-colors"
                    >
                      Continuer vers le paiement
                    </button>
                  </div>
                </form>
              </div>
            )}
            
            {currentStep === 'payment' && (
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-6">Informations de paiement</h2>
                <div className="mb-6 flex items-center gap-4">
                  <div className="p-3 border border-[#A7C4E2] bg-[#A7C4E2] bg-opacity-10 rounded-md">
                    <CreditCard size={24} className="text-[#A7C4E2]" />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-800">Carte bancaire</h3>
                    <p className="text-sm text-gray-500">Paiement sécurisé par carte bancaire</p>
                  </div>
                </div>
                
                <form onSubmit={handlePaymentSubmit}>
                  <div className="mb-6">
                    <label htmlFor="cardNumber" className="block text-sm font-medium text-gray-700 mb-1">
                      Numéro de carte *
                    </label>
                    <input
                      type="text"
                      id="cardNumber"
                      name="cardNumber"
                      value={paymentInfo.cardNumber}
                      onChange={handlePaymentChange}
                      placeholder="1234 5678 9012 3456"
                      required
                      className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A7C4E2] focus:border-transparent"
                    />
                  </div>
                  
                  <div className="mb-6">
                    <label htmlFor="cardName" className="block text-sm font-medium text-gray-700 mb-1">
                      Nom sur la carte *
                    </label>
                    <input
                      type="text"
                      id="cardName"
                      name="cardName"
                      value={paymentInfo.cardName}
                      onChange={handlePaymentChange}
                      required
                      className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A7C4E2] focus:border-transparent"
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <div>
                      <label htmlFor="expiry" className="block text-sm font-medium text-gray-700 mb-1">
                        Date d'expiration *
                      </label>
                      <input
                        type="text"
                        id="expiry"
                        name="expiry"
                        value={paymentInfo.expiry}
                        onChange={handlePaymentChange}
                        placeholder="MM/AA"
                        required
                        className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A7C4E2] focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label htmlFor="cvv" className="block text-sm font-medium text-gray-700 mb-1">
                        Code de sécurité *
                      </label>
                      <input
                        type="text"
                        id="cvv"
                        name="cvv"
                        value={paymentInfo.cvv}
                        onChange={handlePaymentChange}
                        placeholder="123"
                        required
                        className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A7C4E2] focus:border-transparent"
                      />
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 mb-8">
                    <ShieldCheck size={20} className="text-green-500" />
                    <span className="text-sm text-gray-600">
                      Vos informations de paiement sont sécurisées par cryptage SSL
                    </span>
                  </div>
                  
                  <div className="flex justify-between">
                    <button
                      type="button"
                      onClick={() => setCurrentStep('shipping')}
                      className="px-6 py-3 border border-gray-300 hover:bg-gray-50 text-gray-700 font-semibold rounded-md transition-colors"
                    >
                      Retour
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-3 bg-[#A7C4E2] hover:bg-[#8CAFD6] text-white font-semibold rounded-md transition-colors"
                    >
                      Vérifier la commande
                    </button>
                  </div>
                </form>
              </div>
            )}
            
            {currentStep === 'review' && (
              <div>
                <h2 className="text-xl font-semibold text-gray-800 mb-6">Vérification de la commande</h2>
                
                <div className="mb-8">
                  <h3 className="text-lg font-medium text-gray-800 mb-4">Adresse de livraison</h3>
                  <div className="bg-gray-50 p-4 rounded-md border border-gray-200">
                    <p className="mb-1"><span className="font-medium">Nom :</span> {shippingInfo.firstName} {shippingInfo.lastName}</p>
                    <p className="mb-1"><span className="font-medium">Email :</span> {shippingInfo.email}</p>
                    <p className="mb-1"><span className="font-medium">Téléphone :</span> {shippingInfo.phone}</p>
                    <p className="mb-1">
                      <span className="font-medium">Adresse :</span> {shippingInfo.address}, {shippingInfo.postalCode} {shippingInfo.city}, {shippingInfo.country}
                    </p>
                  </div>
                </div>
                
                <div className="mb-8">
                  <h3 className="text-lg font-medium text-gray-800 mb-4">Moyen de paiement</h3>
                  <div className="bg-gray-50 p-4 rounded-md border border-gray-200">
                    <p className="mb-1"><span className="font-medium">Numéro de carte :</span> **** **** **** {paymentInfo.cardNumber.slice(-4)}</p>
                    <p className="mb-1"><span className="font-medium">Titulaire :</span> {paymentInfo.cardName}</p>
                    <p className="mb-1"><span className="font-medium">Expiration :</span> {paymentInfo.expiry}</p>
                  </div>
                </div>
                
                <div className="mb-8">
                  <h3 className="text-lg font-medium text-gray-800 mb-4">Articles commandés</h3>
                  <div className="bg-gray-50 p-4 rounded-md border border-gray-200">
                    <div className="space-y-4">
                      {items.map(item => (
                        <div key={`${item.product.id}-${item.variant.id}`} className="flex items-center gap-4">
                          <img 
                            src={item.product.images[0]} 
                            alt={item.product.name} 
                            className="w-16 h-16 object-cover object-center rounded-md"
                          />
                          <div className="flex-1">
                            <p className="font-medium text-gray-800">{item.product.name}</p>
                            <p className="text-sm text-gray-500">{item.variant.name}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-medium">{(item.variant.price * item.quantity).toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}</p>
                            <p className="text-sm text-gray-500">Qté : {item.quantity}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                
                <form onSubmit={handleReviewSubmit}>
                  <div className="flex justify-between">
                    <button
                      type="button"
                      onClick={() => setCurrentStep('payment')}
                      className="px-6 py-3 border border-gray-300 hover:bg-gray-50 text-gray-700 font-semibold rounded-md transition-colors"
                    >
                      Retour
                    </button>
                    <button
                      type="submit"
                      className="px-6 py-3 bg-[#A7C4E2] hover:bg-[#8CAFD6] text-white font-semibold rounded-md transition-colors"
                    >
                      Confirmer la commande
                    </button>
                  </div>
                </form>
              </div>
            )}
            
            {currentStep === 'confirmation' && (
              <div className="text-center py-12">
                <div className="flex justify-center mb-6">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                    <CheckCircle size={32} className="text-green-500" />
                  </div>
                </div>
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">Merci pour votre commande !</h2>
                <p className="text-gray-600 mb-8 max-w-lg mx-auto">
                  Votre commande a été enregistrée avec succès. Un email de confirmation a été envoyé à {shippingInfo.email}.
                </p>
                <div className="bg-gray-50 p-4 rounded-md border border-gray-200 mb-8 inline-block">
                  <p className="font-medium text-gray-800">Référence de commande : #DOR{Math.floor(Math.random() * 10000000)}</p>
                </div>
                <div>
                  <Link 
                    to="/"
                    className="px-6 py-3 bg-[#A7C4E2] hover:bg-[#8CAFD6] text-white font-semibold rounded-md transition-colors"
                  >
                    Continuer mes achats
                  </Link>
                </div>
              </div>
            )}
          </div>
          
          {currentStep !== 'confirmation' && (
            <div className="lg:col-span-1">
              <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
                <h2 className="text-xl font-semibold text-gray-800 mb-6">Récapitulatif</h2>
                
                <div className="max-h-48 overflow-y-auto mb-6">
                  {items.map(item => (
                    <div 
                      key={`${item.product.id}-${item.variant.id}`} 
                      className="flex items-center gap-3 mb-3 pb-3 border-b border-gray-200 last:border-b-0"
                    >
                      <img 
                        src={item.product.images[0]} 
                        alt={item.product.name} 
                        className="w-16 h-16 object-cover object-center rounded-md"
                      />
                      <div>
                        <p className="font-medium text-gray-800 text-sm line-clamp-1">{item.product.name}</p>
                        <p className="text-xs text-gray-500">{item.variant.name}</p>
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-xs text-gray-500">Qté : {item.quantity}</span>
                          <span className="text-sm font-medium">{(item.variant.price * item.quantity).toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="space-y-3 border-b border-gray-200 pb-4 mb-4">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Sous-total</span>
                    <span className="font-medium">
                      {total.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Livraison</span>
                    <span className="font-medium">
                      {shipping === 0 
                        ? 'Gratuite' 
                        : shipping.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })
                      }
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">TVA (20%)</span>
                    <span className="font-medium">
                      {tax.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}
                    </span>
                  </div>
                </div>
                
                <div className="flex justify-between mb-6">
                  <span className="text-lg font-semibold text-gray-800">Total</span>
                  <span className="text-lg font-semibold text-gray-800">
                    {grandTotal.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;