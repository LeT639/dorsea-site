import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { Plus, Minus, Trash2, ChevronLeft, ShoppingBag } from 'lucide-react';

const CartPage: React.FC = () => {
  const { items, removeFromCart, updateQuantity, getCartTotal, clearCart } = useCart();
  const navigate = useNavigate();
  
  const total = getCartTotal();
  const shipping = total >= 500 ? 0 : 35;
  const grandTotal = total + shipping;
  
  if (items.length === 0) {
    return (
      <div className="pt-24 pb-16">
        <div className="container mx-auto px-4 py-16 text-center">
          <div className="mb-6 flex justify-center">
            <ShoppingBag size={64} className="text-gray-300" />
          </div>
          <h1 className="text-3xl font-semibold text-gray-800 mb-4">Votre panier est vide</h1>
          <p className="text-gray-600 mb-8">
            Vous n'avez pas encore ajouté de produits à votre panier.
          </p>
          <Link 
            to="/"
            className="inline-block px-6 py-3 bg-[#A7C4E2] hover:bg-[#8CAFD6] text-white font-semibold rounded-md transition-colors"
          >
            Continuer mes achats
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-semibold text-gray-800 mb-8">Votre Panier</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2">
            <div className="border-b border-gray-200 pb-4 mb-4 hidden md:grid md:grid-cols-12 gap-4">
              <div className="md:col-span-6">
                <span className="text-sm font-medium text-gray-600">Produit</span>
              </div>
              <div className="md:col-span-2 text-center">
                <span className="text-sm font-medium text-gray-600">Prix</span>
              </div>
              <div className="md:col-span-2 text-center">
                <span className="text-sm font-medium text-gray-600">Quantité</span>
              </div>
              <div className="md:col-span-2 text-right">
                <span className="text-sm font-medium text-gray-600">Total</span>
              </div>
            </div>
            
            <div className="space-y-6">
              {items.map(item => (
                <div key={`${item.product.id}-${item.variant.id}`} className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center border-b border-gray-200 pb-6">
                  <div className="md:col-span-6 flex items-center gap-4">
                    <Link to={`/product/${item.product.id}`} className="w-20 h-20 flex-shrink-0">
                      <img 
                        src={item.product.images[0]} 
                        alt={item.product.name} 
                        className="w-full h-full object-cover object-center rounded-md"
                      />
                    </Link>
                    <div>
                      <Link 
                        to={`/product/${item.product.id}`}
                        className="text-gray-800 font-medium hover:text-[#A7C4E2] transition-colors"
                      >
                        {item.product.name}
                      </Link>
                      <p className="text-sm text-gray-500">{item.variant.name}</p>
                      <button
                        onClick={() => removeFromCart(item.product.id, item.variant.id)}
                        className="mt-2 text-red-500 text-sm flex items-center hover:text-red-700 transition-colors md:hidden"
                      >
                        <Trash2 size={14} className="mr-1" /> Supprimer
                      </button>
                    </div>
                  </div>
                  
                  <div className="md:col-span-2 text-center">
                    <div className="md:hidden text-sm text-gray-500">Prix :</div>
                    <span>{item.variant.price.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}</span>
                  </div>
                  
                  <div className="md:col-span-2 flex justify-center">
                    <div className="flex items-center">
                      <button
                        onClick={() => updateQuantity(item.product.id, item.variant.id, item.quantity - 1)}
                        className="w-8 h-8 flex items-center justify-center border border-gray-300 rounded-l-md hover:bg-gray-100 transition-colors"
                        aria-label="Diminuer la quantité"
                      >
                        <Minus size={14} />
                      </button>
                      <input
                        type="number"
                        min="1"
                        value={item.quantity}
                        onChange={(e) => updateQuantity(item.product.id, item.variant.id, parseInt(e.target.value) || 1)}
                        className="w-12 h-8 border-t border-b border-gray-300 text-center focus:outline-none"
                      />
                      <button
                        onClick={() => updateQuantity(item.product.id, item.variant.id, item.quantity + 1)}
                        className="w-8 h-8 flex items-center justify-center border border-gray-300 rounded-r-md hover:bg-gray-100 transition-colors"
                        aria-label="Augmenter la quantité"
                      >
                        <Plus size={14} />
                      </button>
                    </div>
                  </div>
                  
                  <div className="md:col-span-2 flex items-center justify-between md:justify-end">
                    <div className="md:hidden text-sm text-gray-500">Total :</div>
                    <span className="font-medium">
                      {(item.variant.price * item.quantity).toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}
                    </span>
                    <button
                      onClick={() => removeFromCart(item.product.id, item.variant.id)}
                      className="ml-4 text-gray-400 hover:text-red-500 transition-colors hidden md:block"
                      aria-label="Supprimer l'article"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="flex items-center justify-between mt-8">
              <button
                onClick={() => navigate(-1)}
                className="flex items-center text-gray-600 hover:text-[#A7C4E2] transition-colors"
              >
                <ChevronLeft size={16} className="mr-1" />
                Continuer mes achats
              </button>
              
              <button
                onClick={clearCart}
                className="text-red-500 font-medium hover:text-red-700 transition-colors"
              >
                Vider le panier
              </button>
            </div>
          </div>
          
          <div className="lg:col-span-1">
            <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
              <h2 className="text-xl font-semibold text-gray-800 mb-6">Récapitulatif</h2>
              
              <div className="space-y-3 border-b border-gray-200 pb-4 mb-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">Sous-total</span>
                  <span className="font-medium">
                    {total.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Livraison</span>
                  <span className="font-medium">
                    {shipping === 0 
                      ? 'Gratuite' 
                      : shipping.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })
                    }
                  </span>
                </div>
              </div>
              
              <div className="flex justify-between mb-6">
                <span className="text-lg font-semibold text-gray-800">Total</span>
                <span className="text-lg font-semibold text-gray-800">
                  {grandTotal.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}
                </span>
              </div>
              
              <Link 
                to="/checkout"
                className="w-full block text-center px-6 py-3 bg-[#A7C4E2] hover:bg-[#8CAFD6] text-white font-semibold rounded-md transition-colors"
              >
                Passer la commande
              </Link>
              
              <div className="mt-6">
                <p className="text-sm text-gray-500 mb-3">Nous acceptons :</p>
                <div className="flex space-x-2">
                  <img src="https://cdn.simpleicons.org/visa/888888" alt="Visa" className="h-6 w-auto opacity-70" />
                  <img src="https://cdn.simpleicons.org/mastercard/888888" alt="Mastercard" className="h-6 w-auto opacity-70" />
                  <img src="https://cdn.simpleicons.org/paypal/888888" alt="PayPal" className="h-6 w-auto opacity-70" />
                  <img src="https://cdn.simpleicons.org/applepay/888888" alt="Apple Pay" className="h-6 w-auto opacity-70" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;