import React, { useState } from 'react';
import { User, Package, Heart, Clock, Settings, LogOut } from 'lucide-react';

type AccountTab = 'profile' | 'orders' | 'wishlist' | 'history' | 'settings';

const AccountPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AccountTab>('profile');
  
  // Mock user data
  const user = {
    firstName: 'Sophie',
    lastName: 'Martin',
    email: 'sophie.martin@example.com',
    phone: '+33 6 12 34 56 78',
    address: '123 Rue de Paris',
    city: 'Paris',
    postalCode: '75001',
    country: 'France'
  };
  
  const tabs = [
    { id: 'profile', label: 'My Profile', icon: <User size={20} /> },
    { id: 'orders', label: 'My Orders', icon: <Package size={20} /> },
    { id: 'wishlist', label: 'Wishlist', icon: <Heart size={20} /> },
    { id: 'history', label: 'Browsing History', icon: <Clock size={20} /> },
    { id: 'settings', label: 'Account Settings', icon: <Settings size={20} /> },
  ];

  return (
    <div className="pt-24 pb-16">
      <div className="bg-[#F5F2EA] py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-semibold text-gray-800">Your Account</h1>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Navigation */}
          <aside className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-6 bg-[#A7C4E2] bg-opacity-10 border-b border-gray-100">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-[#A7C4E2] rounded-full flex items-center justify-center text-white text-xl font-semibold">
                    {user.firstName[0]}{user.lastName[0]}
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">{user.firstName} {user.lastName}</h3>
                    <p className="text-sm text-gray-500">{user.email}</p>
                  </div>
                </div>
              </div>
              
              <nav className="p-4">
                <ul className="space-y-1">
                  {tabs.map(tab => (
                    <li key={tab.id}>
                      <button
                        onClick={() => setActiveTab(tab.id as AccountTab)}
                        className={`w-full flex items-center gap-3 px-4 py-3 rounded-md transition-colors ${
                          activeTab === tab.id 
                            ? 'bg-[#A7C4E2] bg-opacity-10 text-[#A7C4E2]' 
                            : 'hover:bg-gray-100 text-gray-700'
                        }`}
                      >
                        {tab.icon}
                        <span>{tab.label}</span>
                      </button>
                    </li>
                  ))}
                  <li className="pt-2 mt-2 border-t border-gray-100">
                    <button
                      className="w-full flex items-center gap-3 px-4 py-3 rounded-md text-red-500 hover:bg-red-50 transition-colors"
                    >
                      <LogOut size={20} />
                      <span>Sign Out</span>
                    </button>
                  </li>
                </ul>
              </nav>
            </div>
          </aside>
          
          {/* Content Area */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
              {/* Profile Tab */}
              {activeTab === 'profile' && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-800 mb-6">Personal Information</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <div>
                      <label className="block text-sm font-medium text-gray-500 mb-1">
                        First Name
                      </label>
                      <input
                        type="text"
                        value={user.firstName}
                        className="w-full p-3 border border-gray-300 rounded-md"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-500 mb-1">
                        Last Name
                      </label>
                      <input
                        type="text"
                        value={user.lastName}
                        className="w-full p-3 border border-gray-300 rounded-md"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <div>
                      <label className="block text-sm font-medium text-gray-500 mb-1">
                        Email Address
                      </label>
                      <input
                        type="email"
                        value={user.email}
                        className="w-full p-3 border border-gray-300 rounded-md"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-500 mb-1">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        value={user.phone}
                        className="w-full p-3 border border-gray-300 rounded-md"
                      />
                    </div>
                  </div>
                  
                  <h2 className="text-xl font-semibold text-gray-800 mb-6 mt-12">Delivery Address</h2>
                  
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-500 mb-1">
                      Street Address
                    </label>
                    <input
                      type="text"
                      value={user.address}
                      className="w-full p-3 border border-gray-300 rounded-md"
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div>
                      <label className="block text-sm font-medium text-gray-500 mb-1">
                        City
                      </label>
                      <input
                        type="text"
                        value={user.city}
                        className="w-full p-3 border border-gray-300 rounded-md"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-500 mb-1">
                        Postal Code
                      </label>
                      <input
                        type="text"
                        value={user.postalCode}
                        className="w-full p-3 border border-gray-300 rounded-md"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-500 mb-1">
                        Country
                      </label>
                      <select
                        className="w-full p-3 border border-gray-300 rounded-md"
                      >
                        <option>France</option>
                        <option>Belgium</option>
                        <option>Switzerland</option>
                        <option>Germany</option>
                        <option>Italy</option>
                        <option>Spain</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="mt-8">
                    <button className="px-6 py-3 bg-[#A7C4E2] hover:bg-[#8CAFD6] text-white font-semibold rounded-md transition-colors">
                      Save Changes
                    </button>
                  </div>
                </div>
              )}
              
              {/* Orders Tab */}
              {activeTab === 'orders' && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-800 mb-6">My Orders</h2>
                  
                  {/* Sample orders */}
                  <div className="space-y-6">
                    <div className="border border-gray-200 rounded-lg overflow-hidden">
                      <div className="p-4 bg-gray-50 border-b border-gray-200 flex flex-wrap justify-between items-center">
                        <div>
                          <p className="text-sm text-gray-500">Order Placed: <span className="font-medium text-gray-700">March 15, 2025</span></p>
                          <p className="text-sm text-gray-500">Order #: <span className="font-medium text-gray-700">DOR5723941</span></p>
                        </div>
                        <div className="mt-2 sm:mt-0">
                          <span className="px-3 py-1 bg-green-100 text-green-700 text-sm font-medium rounded-full">Delivered</span>
                        </div>
                      </div>
                      <div className="p-4">
                        <div className="flex items-center gap-4">
                          <img 
                            src="https://images.pexels.com/photos/6186812/pexels-photo-6186812.jpeg" 
                            alt="Nuage Premium Memory Foam Mattress" 
                            className="w-20 h-20 object-cover object-center rounded-md"
                          />
                          <div>
                            <h3 className="font-medium text-gray-800">Nuage Premium Memory Foam Mattress</h3>
                            <p className="text-sm text-gray-500">Size: Queen (160x200cm)</p>
                            <p className="text-sm font-medium">€899.00</p>
                          </div>
                        </div>
                        <div className="mt-4 flex justify-end gap-3">
                          <button className="px-4 py-2 border border-[#A7C4E2] text-[#A7C4E2] hover:bg-[#A7C4E2] hover:bg-opacity-10 rounded-md transition-colors text-sm font-medium">
                            View Order
                          </button>
                          <button className="px-4 py-2 bg-[#A7C4E2] hover:bg-[#8CAFD6] text-white rounded-md transition-colors text-sm font-medium">
                            Buy Again
                          </button>
                        </div>
                      </div>
                    </div>
                    
                    <div className="border border-gray-200 rounded-lg overflow-hidden">
                      <div className="p-4 bg-gray-50 border-b border-gray-200 flex flex-wrap justify-between items-center">
                        <div>
                          <p className="text-sm text-gray-500">Order Placed: <span className="font-medium text-gray-700">February 28, 2025</span></p>
                          <p className="text-sm text-gray-500">Order #: <span className="font-medium text-gray-700">DOR5689314</span></p>
                        </div>
                        <div className="mt-2 sm:mt-0">
                          <span className="px-3 py-1 bg-green-100 text-green-700 text-sm font-medium rounded-full">Delivered</span>
                        </div>
                      </div>
                      <div className="p-4">
                        <div className="flex items-center gap-4">
                          <img 
                            src="https://images.pexels.com/photos/6186566/pexels-photo-6186566.jpeg" 
                            alt="Riviera Organic Cotton Sheet Set" 
                            className="w-20 h-20 object-cover object-center rounded-md"
                          />
                          <div>
                            <h3 className="font-medium text-gray-800">Riviera Organic Cotton Sheet Set</h3>
                            <p className="text-sm text-gray-500">Size: Double - Color: White</p>
                            <p className="text-sm font-medium">€149.00</p>
                          </div>
                        </div>
                        <div className="mt-4 flex justify-end gap-3">
                          <button className="px-4 py-2 border border-[#A7C4E2] text-[#A7C4E2] hover:bg-[#A7C4E2] hover:bg-opacity-10 rounded-md transition-colors text-sm font-medium">
                            View Order
                          </button>
                          <button className="px-4 py-2 bg-[#A7C4E2] hover:bg-[#8CAFD6] text-white rounded-md transition-colors text-sm font-medium">
                            Buy Again
                          </button>
                        </div>
                      </div>
                    </div>
                    
                    <div className="border border-gray-200 rounded-lg overflow-hidden">
                      <div className="p-4 bg-gray-50 border-b border-gray-200 flex flex-wrap justify-between items-center">
                        <div>
                          <p className="text-sm text-gray-500">Order Placed: <span className="font-medium text-gray-700">January 10, 2025</span></p>
                          <p className="text-sm text-gray-500">Order #: <span className="font-medium text-gray-700">DOR5521846</span></p>
                        </div>
                        <div className="mt-2 sm:mt-0">
                          <span className="px-3 py-1 bg-green-100 text-green-700 text-sm font-medium rounded-full">Delivered</span>
                        </div>
                      </div>
                      <div className="p-4">
                        <div className="flex items-center gap-4">
                          <img 
                            src="https://images.pexels.com/photos/1743229/pexels-photo-1743229.jpeg" 
                            alt="Opéra Premium Bed Frame" 
                            className="w-20 h-20 object-cover object-center rounded-md"
                          />
                          <div>
                            <h3 className="font-medium text-gray-800">Opéra Premium Bed Frame</h3>
                            <p className="text-sm text-gray-500">Size: Queen (160x200cm) - Color: Beige</p>
                            <p className="text-sm font-medium">€899.00</p>
                          </div>
                        </div>
                        <div className="mt-4 flex justify-end gap-3">
                          <button className="px-4 py-2 border border-[#A7C4E2] text-[#A7C4E2] hover:bg-[#A7C4E2] hover:bg-opacity-10 rounded-md transition-colors text-sm font-medium">
                            View Order
                          </button>
                          <button className="px-4 py-2 bg-[#A7C4E2] hover:bg-[#8CAFD6] text-white rounded-md transition-colors text-sm font-medium">
                            Buy Again
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Wishlist Tab */}
              {activeTab === 'wishlist' && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-800 mb-6">My Wishlist</h2>
                  <p className="text-gray-600">You have no items in your wishlist yet.</p>
                </div>
              )}
              
              {/* Browsing History Tab */}
              {activeTab === 'history' && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-800 mb-6">Recently Viewed</h2>
                  
                  {/* Sample browsing history */}
                  <div className="space-y-4">
                    <div className="border border-gray-200 rounded-lg p-4 flex items-center gap-4">
                      <img 
                        src="https://images.pexels.com/photos/6186812/pexels-photo-6186812.jpeg" 
                        alt="Nuage Premium Memory Foam Mattress" 
                        className="w-16 h-16 object-cover object-center rounded-md"
                      />
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-800">Nuage Premium Memory Foam Mattress</h3>
                        <p className="text-sm text-gray-500">Viewed 2 hours ago</p>
                      </div>
                      <button className="px-4 py-2 bg-[#A7C4E2] hover:bg-[#8CAFD6] text-white rounded-md transition-colors text-sm font-medium">
                        View Product
                      </button>
                    </div>
                    
                    <div className="border border-gray-200 rounded-lg p-4 flex items-center gap-4">
                      <img 
                        src="https://images.pexels.com/photos/6186566/pexels-photo-6186566.jpeg" 
                        alt="Riviera Organic Cotton Sheet Set" 
                        className="w-16 h-16 object-cover object-center rounded-md"
                      />
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-800">Riviera Organic Cotton Sheet Set</h3>
                        <p className="text-sm text-gray-500">Viewed 1 day ago</p>
                      </div>
                      <button className="px-4 py-2 bg-[#A7C4E2] hover:bg-[#8CAFD6] text-white rounded-md transition-colors text-sm font-medium">
                        View Product
                      </button>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Settings Tab */}
              {activeTab === 'settings' && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-800 mb-6">Account Settings</h2>
                  
                  <div className="space-y-6">
                    <div className="p-4 border border-gray-200 rounded-lg">
                      <h3 className="font-medium text-gray-800 mb-4">Email Notifications</h3>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <label htmlFor="order-updates" className="text-gray-600">Order updates</label>
                          <input 
                            type="checkbox" 
                            id="order-updates" 
                            className="h-4 w-4 text-[#A7C4E2] focus:ring-[#A7C4E2]" 
                            defaultChecked 
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <label htmlFor="promotions" className="text-gray-600">Promotions and sales</label>
                          <input 
                            type="checkbox" 
                            id="promotions" 
                            className="h-4 w-4 text-[#A7C4E2] focus:ring-[#A7C4E2]" 
                            defaultChecked 
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <label htmlFor="blog" className="text-gray-600">New blog articles</label>
                          <input 
                            type="checkbox" 
                            id="blog" 
                            className="h-4 w-4 text-[#A7C4E2] focus:ring-[#A7C4E2]" 
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <label htmlFor="product-updates" className="text-gray-600">Product updates and restocks</label>
                          <input 
                            type="checkbox" 
                            id="product-updates" 
                            className="h-4 w-4 text-[#A7C4E2] focus:ring-[#A7C4E2]" 
                            defaultChecked 
                          />
                        </div>
                      </div>
                    </div>
                    
                    <div className="p-4 border border-gray-200 rounded-lg">
                      <h3 className="font-medium text-gray-800 mb-4">Password</h3>
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-500 mb-1">
                            Current Password
                          </label>
                          <input
                            type="password"
                            className="w-full p-3 border border-gray-300 rounded-md"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-500 mb-1">
                            New Password
                          </label>
                          <input
                            type="password"
                            className="w-full p-3 border border-gray-300 rounded-md"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-500 mb-1">
                            Confirm New Password
                          </label>
                          <input
                            type="password"
                            className="w-full p-3 border border-gray-300 rounded-md"
                          />
                        </div>
                        <button className="px-4 py-2 bg-[#A7C4E2] hover:bg-[#8CAFD6] text-white rounded-md transition-colors text-sm font-medium">
                          Update Password
                        </button>
                      </div>
                    </div>
                    
                    <div className="p-4 border border-gray-200 rounded-lg">
                      <h3 className="font-medium text-gray-800 mb-4">Delete Account</h3>
                      <p className="text-gray-600 mb-4">
                        Once you delete your account, there is no going back. Please be certain.
                      </p>
                      <button className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-md transition-colors text-sm font-medium">
                        Delete Account
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountPage;