import React from 'react';
import { blogPosts } from '../data/blogPosts';
import BlogPostCard from '../components/blog/BlogPostCard';

const BlogPage: React.FC = () => {
  // Get featured post (first one)
  const featuredPost = blogPosts[0];
  // Get rest of posts
  const otherPosts = blogPosts.slice(1);

  return (
    <div className="pt-24 pb-16">
      <div className="bg-[#F5F2EA] py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-semibold text-gray-800 mb-4">Sleep Blog</h1>
          <p className="text-gray-600 max-w-3xl">
            Expert advice, tips, and insights on sleep health, mattress care, and bedroom design. 
            Discover how to transform your sleep experience for better health and wellbeing.
          </p>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {featuredPost && <BlogPostCard post={featuredPost} featured />}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {otherPosts.map(post => (
            <BlogPostCard key={post.id} post={post} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default BlogPage;