import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getProduct, getProductsByCategory } from '../data/products';
import { useCart } from '../context/CartContext';
import { Check, Truck, Shield, Star, ChevronRight } from 'lucide-react';
import ProductGrid from '../components/products/ProductGrid';

const ProductPage: React.FC = () => {
  const { productId } = useParams<{ productId: string }>();
  const { addToCart } = useCart();
  
  const product = productId ? getProduct(productId) : undefined;
  const [selectedVariant, setSelectedVariant] = useState(product?.variants[0]);
  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(0);
  
  const relatedProducts = product 
    ? getProductsByCategory(product.category).filter(p => p.id !== product.id).slice(0, 4) 
    : [];

  useEffect(() => {
    if (product) {
      const defaultVariant = product.variants.find(v => v.inStock) || product.variants[0];
      setSelectedVariant(defaultVariant);
      setQuantity(1);
      setActiveImage(0);
      window.scrollTo(0, 0);
    }
  }, [product]);

  if (!product || !selectedVariant) {
    return <div className="container mx-auto px-4 py-16">Produit non trouvé</div>;
  }

  const handleVariantChange = (variantId: string) => {
    const variant = product.variants.find(v => v.id === variantId);
    if (variant) {
      setSelectedVariant(variant);
    }
  };

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value > 0) {
      setQuantity(value);
    }
  };

  const handleAddToCart = () => {
    addToCart(product, selectedVariant, quantity);
  };

  const hasDiscount = selectedVariant.originalPrice && selectedVariant.originalPrice > selectedVariant.price;
  const discountPercentage = hasDiscount 
    ? Math.round(((selectedVariant.originalPrice! - selectedVariant.price) / selectedVariant.originalPrice!) * 100) 
    : 0;

  return (
    <div className="pt-24 pb-16">
      <div className="bg-gray-50 py-4 border-t border-b border-gray-100">
        <div className="container mx-auto px-4">
          <nav className="flex text-sm">
            <Link to="/" className="text-gray-500 hover:text-[#A7C4E2]">Accueil</Link>
            <ChevronRight size={16} className="mx-2 text-gray-400" />
            <Link to={`/category/${product.category}`} className="text-gray-500 hover:text-[#A7C4E2] capitalize">
              {product.category.replace('-', ' ')}
            </Link>
            <ChevronRight size={16} className="mx-2 text-gray-400" />
            <span className="text-gray-700 truncate">{product.name}</span>
          </nav>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <div className="aspect-square overflow-hidden rounded-lg bg-gray-100 mb-4">
              <img 
                src={product.images[activeImage]} 
                alt={product.name} 
                className="w-full h-full object-cover object-center"
              />
            </div>
            <div className="grid grid-cols-4 gap-4">
              {product.images.map((image, index) => (
                <button 
                  key={index}
                  onClick={() => setActiveImage(index)}
                  className={`aspect-square rounded-md overflow-hidden ${
                    activeImage === index ? 'ring-2 ring-[#A7C4E2]' : 'ring-1 ring-gray-200'
                  }`}
                >
                  <img 
                    src={image} 
                    alt={`${product.name} - vue ${index + 1}`} 
                    className="w-full h-full object-cover object-center"
                  />
                </button>
              ))}
            </div>
          </div>
          
          <div>
            <h1 className="text-3xl font-semibold text-gray-800 mb-2">{product.name}</h1>
            
            <div className="flex items-center mb-4">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i}
                    size={18}
                    className={`${i < Math.floor(product.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                  />
                ))}
              </div>
              <span className="ml-2 text-sm text-gray-600">
                {product.rating.toFixed(1)} ({product.reviewCount} avis)
              </span>
            </div>
            
            <div className="flex items-end gap-2 mb-6">
              <span className="text-2xl font-semibold">
                {selectedVariant.price.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}
              </span>
              {hasDiscount && (
                <>
                  <span className="text-lg text-gray-500 line-through">
                    {selectedVariant.originalPrice!.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}
                  </span>
                  <span className="px-2 py-1 bg-red-500 text-white text-xs font-semibold rounded">
                    -{discountPercentage}%
                  </span>
                </>
              )}
            </div>
            
            <div className="space-y-6">
              <p className="text-gray-600">{product.shortDescription}</p>
              
              <div>
                <h3 className="text-sm text-gray-700 font-medium mb-3">Sélectionnez une option :</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {product.variants.map(variant => (
                    <button
                      key={variant.id}
                      onClick={() => handleVariantChange(variant.id)}
                      disabled={!variant.inStock}
                      className={`flex justify-between items-center px-4 py-3 border rounded-md transition-colors ${
                        selectedVariant.id === variant.id 
                          ? 'border-[#A7C4E2] bg-[#A7C4E2] bg-opacity-10'
                          : 'border-gray-300 hover:border-gray-400'
                      } ${!variant.inStock ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      <span className="text-sm font-medium">{variant.name}</span>
                      {selectedVariant.id === variant.id && (
                        <Check size={16} className="text-[#A7C4E2]" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="flex items-center">
                <span 
                  className={`w-3 h-3 rounded-full ${
                    selectedVariant.inStock ? 'bg-green-500' : 'bg-red-500'
                  } mr-2`}
                ></span>
                <span className="text-sm">
                  {selectedVariant.inStock ? 'En stock' : 'Rupture de stock'}
                </span>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="w-28">
                  <label htmlFor="quantity" className="sr-only">Quantité</label>
                  <input
                    type="number"
                    id="quantity"
                    min="1"
                    value={quantity}
                    onChange={handleQuantityChange}
                    disabled={!selectedVariant.inStock}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#A7C4E2] focus:border-transparent"
                  />
                </div>
                
                <button
                  onClick={handleAddToCart}
                  disabled={!selectedVariant.inStock}
                  className={`flex-grow px-6 py-3 ${
                    selectedVariant.inStock 
                      ? 'bg-[#A7C4E2] hover:bg-[#8CAFD6]' 
                      : 'bg-gray-300 cursor-not-allowed'
                  } text-white font-semibold rounded-md transition-colors`}
                >
                  {selectedVariant.inStock ? 'Ajouter au panier' : 'Rupture de stock'}
                </button>
              </div>
              
              <div className="space-y-3 py-4 border-t border-b border-gray-200">
                <div className="flex items-center gap-3 text-sm text-gray-600">
                  <Truck size={18} className="text-[#A7C4E2]" />
                  <span>Livraison gratuite dès 500€ d'achat</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-gray-600">
                  <Shield size={18} className="text-[#A7C4E2]" />
                  <span>{product.category === 'matelas' ? 'Essai 100 nuits' : '30 jours'} satisfait ou remboursé</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-16">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              <button className="border-[#A7C4E2] text-[#A7C4E2] whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm">
                Description
              </button>
              <button className="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm">
                Caractéristiques
              </button>
              <button className="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm">
                Avis ({product.reviewCount})
              </button>
            </nav>
          </div>
          
          <div className="py-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <h2 className="text-xl font-semibold text-gray-800 mb-4">Description du produit</h2>
                <div className="prose prose-blue max-w-none text-gray-600">
                  <p>{product.description}</p>
                </div>
              </div>
              
              <div className="bg-[#F5F2EA] p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Points clés</h3>
                <ul className="space-y-3">
                  {product.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <Check size={18} className="text-[#A7C4E2] mt-0.5 flex-shrink-0" />
                      <span className="text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
        
        {relatedProducts.length > 0 && (
          <div className="mt-16">
            <h2 className="text-2xl font-semibold text-gray-800 mb-8">Vous aimerez aussi</h2>
            <ProductGrid products={relatedProducts} />
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductPage;