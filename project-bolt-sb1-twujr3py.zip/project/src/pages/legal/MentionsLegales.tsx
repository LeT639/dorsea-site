import React from 'react';

const MentionsLegales: React.FC = () => {
  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-semibold text-gray-800 mb-8">Mentions Légales</h1>
        
        <div className="prose max-w-none">
          <h2>1. Informations légales</h2>
          <p>
            Le site Dorséa est édité par :<br />
            [Nom de la société]<br />
            [Forme juridique] au capital de [montant] euros<br />
            [Adresse du siège social]<br />
            RCS [Ville] [Numéro]<br />
            N° TVA intracommunautaire : [Numéro]<br />
            Téléphone : [Numéro]<br />
            Email : [Adresse email]
          </p>

          <h2>2. Directeur de la publication</h2>
          <p>[Nom et fonction du directeur de la publication]</p>

          <h2>3. Hébergeur</h2>
          <p>
            Le site est hébergé par :<br />
            [Nom de l'hébergeur]<br />
            [Adresse de l'hébergeur]<br />
            [Téléphone de l'hébergeur]
          </p>

          <h2>4. Propriété intellectuelle</h2>
          <p>
            L'ensemble du contenu de ce site (structure, textes, images, logos, base de données...) 
            est protégé par le droit d'auteur et est la propriété exclusive de [Nom de la société]. 
            Toute reproduction, représentation, modification, publication, adaptation totale ou 
            partielle des éléments du site, quel que soit le moyen ou le procédé utilisé, est 
            interdite, sauf autorisation écrite préalable.
          </p>

          <h2>5. Données personnelles</h2>
          <p>
            Les informations recueillies sur ce site sont traitées selon notre politique de 
            confidentialité, conformément au Règlement Général sur la Protection des Données (RGPD). 
            Vous disposez d'un droit d'accès, de rectification, d'effacement et de portabilité 
            des données vous concernant.
          </p>

          <h2>6. Cookies</h2>
          <p>
            Le site utilise des cookies pour améliorer l'expérience utilisateur. Vous pouvez 
            configurer votre navigateur pour refuser les cookies ou être alerté lors de leur 
            utilisation.
          </p>

          <h2>7. Liens hypertextes</h2>
          <p>
            Le site peut contenir des liens vers d'autres sites. [Nom de la société] n'est pas 
            responsable du contenu des sites vers lesquels ces liens pointent.
          </p>

          <h2>8. Droit applicable</h2>
          <p>
            Les présentes mentions légales sont soumises au droit français. En cas de litige, 
            les tribunaux français seront seuls compétents.
          </p>
        </div>
      </div>
    </div>
  );
};

export default MentionsLegales;