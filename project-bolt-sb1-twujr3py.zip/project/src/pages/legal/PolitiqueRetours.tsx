import React from 'react';

const PolitiqueRetours: React.FC = () => {
  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-semibold text-gray-800 mb-8">Politique de Retours</h1>
        
        <div className="prose max-w-none">
          <h2>1. Délai de retour</h2>
          <p>
            Nous proposons les délais de retour suivants :
          </p>
          <ul>
            <li>Matelas : 100 nuits d'essai</li>
            <li>Autres produits : 30 jours à compter de la réception</li>
          </ul>

          <h2>2. Conditions de retour</h2>
          <p>
            Pour être éligible à un retour, votre article doit être :
          </p>
          <ul>
            <li>Dans son état d'origine</li>
            <li>Non utilisé (sauf pour les matelas pendant la période d'essai)</li>
            <li>Dans son emballage d'origine si possible</li>
            <li>Accompagné de la facture ou du bon de livraison</li>
          </ul>

          <h2>3. Procédure de retour</h2>
          <p>
            Pour retourner un article :
          </p>
          <ol>
            <li>Contactez notre service client pour initier le retour</li>
            <li>Nous organiserons la collecte à votre domicile</li>
            <li>Emballez soigneusement l'article</li>
            <li>Remettez l'article à notre transporteur</li>
          </ol>

          <h2>4. Frais de retour</h2>
          <p>
            Les frais de retour sont gratuits pour :
          </p>
          <ul>
            <li>Les retours pendant la période d'essai des matelas</li>
            <li>Les articles défectueux ou non conformes</li>
            <li>Les erreurs de livraison de notre part</li>
          </ul>

          <h2>5. Remboursement</h2>
          <p>
            Une fois votre retour reçu et vérifié, nous vous enverrons un email pour vous 
            notifier que nous avons reçu votre retour. Nous vous informerons également de 
            l'approbation ou du rejet de votre remboursement.
          </p>
          <p>
            Si votre remboursement est approuvé, il sera automatiquement effectué sur votre 
            moyen de paiement initial dans un délai de 14 jours maximum.
          </p>

          <h2>6. Articles endommagés ou défectueux</h2>
          <p>
            Si vous recevez un article endommagé ou défectueux, veuillez nous contacter 
            immédiatement. Nous organiserons le retour et le remplacement de l'article sans 
            frais supplémentaires.
          </p>

          <h2>7. Exceptions</h2>
          <p>
            Certains articles ne peuvent pas être retournés, notamment :
          </p>
          <ul>
            <li>Les articles personnalisés</li>
            <li>Les articles d'hygiène déballés</li>
            <li>Les articles en promotion (sauf défaut)</li>
          </ul>

          <h2>8. Contact</h2>
          <p>
            Pour toute question concernant notre politique de retour, contactez notre service client :<br />
            Téléphone : [Numéro]<br />
            Email : [Email]<br />
            Du lundi au vendredi de 9h à 18h
          </p>
        </div>
      </div>
    </div>
  );
};

export default PolitiqueRetours;