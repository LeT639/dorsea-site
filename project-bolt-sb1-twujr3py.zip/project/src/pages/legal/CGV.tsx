import React from 'react';

const CGV: React.FC = () => {
  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-semibold text-gray-800 mb-8">Conditions Générales de Vente</h1>
        
        <div className="prose max-w-none">
          <h2>Article 1 - Objet</h2>
          <p>
            Les présentes conditions générales de vente régissent les relations contractuelles 
            entre la société [Nom de la société], ci-après dénommée "le vendeur" et toute 
            personne effectuant un achat sur le site www.dorsea.fr, ci-après dénommée "l'acheteur".
          </p>

          <h2>Article 2 - Prix</h2>
          <p>
            Les prix sont indiqués en euros toutes taxes comprises (TTC), hors frais de livraison. 
            Le vendeur se réserve le droit de modifier ses prix à tout moment, les produits 
            étant facturés au prix en vigueur lors de l'enregistrement de la commande.
          </p>

          <h2>Article 3 - Commande</h2>
          <p>
            La commande n'est définitive qu'après confirmation du paiement. Le vendeur se réserve 
            le droit de refuser ou d'annuler toute commande d'un client avec lequel il existerait 
            un litige.
          </p>

          <h2>Article 4 - Paiement</h2>
          <p>
            Le paiement s'effectue en ligne par carte bancaire ou PayPal. La commande sera 
            traitée dès réception du paiement complet.
          </p>

          <h2>Article 5 - Livraison</h2>
          <p>
            Les délais de livraison sont donnés à titre indicatif. La livraison est effectuée 
            à l'adresse indiquée par l'acheteur lors de la commande. Les frais de livraison 
            sont offerts à partir de 500€ d'achat.
          </p>

          <h2>Article 6 - Droit de rétractation</h2>
          <p>
            L'acheteur dispose d'un délai de 14 jours à compter de la réception du produit pour 
            exercer son droit de rétractation. Pour les matelas, ce délai est étendu à 100 nuits 
            d'essai.
          </p>

          <h2>Article 7 - Garantie</h2>
          <p>
            Tous nos produits bénéficient de la garantie légale de conformité et de la garantie 
            des vices cachés. Les matelas bénéficient d'une garantie commerciale de 10 ans.
          </p>

          <h2>Article 8 - Service client</h2>
          <p>
            Pour toute question ou réclamation, notre service client est disponible :<br />
            - Par téléphone : [Numéro]<br />
            - Par email : [Email]<br />
            - Du lundi au vendredi de 9h à 18h
          </p>

          <h2>Article 9 - Protection des données</h2>
          <p>
            Les données personnelles collectées sont traitées conformément à notre politique 
            de confidentialité et au RGPD.
          </p>

          <h2>Article 10 - Droit applicable</h2>
          <p>
            Les présentes conditions générales de vente sont soumises au droit français. 
            En cas de litige, les tribunaux français seront seuls compétents.
          </p>
        </div>
      </div>
    </div>
  );
};

export default CGV;