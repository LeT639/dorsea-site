import React from 'react';

const PolitiqueConfidentialite: React.FC = () => {
  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-semibold text-gray-800 mb-8">Politique de Confidentialité</h1>
        
        <div className="prose max-w-none">
          <h2>1. Collecte des données personnelles</h2>
          <p>
            Nous collectons les données personnelles suivantes :
          </p>
          <ul>
            <li>Nom et prénom</li>
            <li>Adresse email</li>
            <li>Adresse postale</li>
            <li>Numéro de téléphone</li>
            <li>Données de paiement (traitées de manière sécurisée par nos prestataires de paiement)</li>
            <li>Historique des commandes</li>
          </ul>

          <h2>2. Utilisation des données</h2>
          <p>
            Vos données personnelles sont utilisées pour :
          </p>
          <ul>
            <li>Traiter vos commandes et assurer leur livraison</li>
            <li>Gérer votre compte client</li>
            <li>Vous informer sur nos produits et services</li>
            <li>Améliorer notre service client</li>
            <li>Respecter nos obligations légales</li>
          </ul>

          <h2>3. Protection des données</h2>
          <p>
            Nous mettons en œuvre des mesures techniques et organisationnelles appropriées 
            pour protéger vos données personnelles contre toute perte, altération ou accès 
            non autorisé.
          </p>

          <h2>4. Durée de conservation</h2>
          <p>
            Nous conservons vos données personnelles pendant la durée nécessaire aux finalités 
            pour lesquelles elles ont été collectées, conformément aux exigences légales et 
            réglementaires.
          </p>

          <h2>5. Vos droits</h2>
          <p>
            Conformément au RGPD, vous disposez des droits suivants :
          </p>
          <ul>
            <li>Droit d'accès à vos données</li>
            <li>Droit de rectification</li>
            <li>Droit à l'effacement</li>
            <li>Droit à la limitation du traitement</li>
            <li>Droit à la portabilité des données</li>
            <li>Droit d'opposition</li>
          </ul>

          <h2>6. Cookies</h2>
          <p>
            Notre site utilise des cookies pour améliorer votre expérience de navigation. 
            Vous pouvez configurer votre navigateur pour refuser les cookies ou être alerté 
            lors de leur utilisation.
          </p>

          <h2>7. Partage des données</h2>
          <p>
            Nous ne partageons vos données qu'avec :
          </p>
          <ul>
            <li>Nos prestataires de services (transport, paiement)</li>
            <li>Les autorités compétentes sur demande</li>
          </ul>

          <h2>8. Contact</h2>
          <p>
            Pour toute question concernant notre politique de confidentialité ou pour exercer 
            vos droits, contactez notre délégué à la protection des données :<br />
            Email : [Email du DPO]<br />
            Adresse : [Adresse]
          </p>

          <h2>9. Modifications</h2>
          <p>
            Nous nous réservons le droit de modifier cette politique de confidentialité à tout 
            moment. Les modifications seront publiées sur cette page.
          </p>
        </div>
      </div>
    </div>
  );
};

export default PolitiqueConfidentialite;