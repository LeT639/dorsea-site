import React from 'react';
import Hero from '../components/home/Hero';
import CategoryShowcase from '../components/home/CategoryShowcase';
import ProductGrid from '../components/products/ProductGrid';
import BenefitsSection from '../components/home/BenefitsSection';
import TestimonialsSection from '../components/home/TestimonialsSection';
import { getBestsellerProducts, getNewProducts } from '../data/products';
import { Link } from 'react-router-dom';

const HomePage: React.FC = () => {
  const bestsellers = getBestsellerProducts();
  const newArrivals = getNewProducts();

  return (
    <div>
      <Hero />
      
      <CategoryShowcase />
      
      <section className="py-16 bg-[#F5F2EA]">
        <div className="container mx-auto px-4">
          <ProductGrid 
            products={bestsellers} 
            title="Our Bestsellers" 
            subtitle="Discover our most popular products, loved by customers for their exceptional comfort and quality."
            limit={4}
          />
          <div className="mt-12 text-center">
            <Link 
              to="/category/mattresses" 
              className="inline-block px-6 py-3 border border-[#A7C4E2] hover:bg-[#A7C4E2] hover:text-white text-[#A7C4E2] font-semibold rounded-md transition-colors duration-300"
            >
              View All Products
            </Link>
          </div>
        </div>
      </section>
      
      <BenefitsSection />
      
      {newArrivals.length > 0 && (
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <ProductGrid 
              products={newArrivals} 
              title="New Arrivals" 
              subtitle="Be the first to experience our latest innovations in sleep comfort."
              limit={4}
            />
            <div className="mt-12 text-center">
              <Link 
                to="/category/mattresses" 
                className="inline-block px-6 py-3 bg-[#A7C4E2] hover:bg-[#8CAFD6] text-white font-semibold rounded-md transition-colors duration-300"
              >
                Shop New Arrivals
              </Link>
            </div>
          </div>
        </section>
      )}
      
      <TestimonialsSection />
      
      <section className="py-16 bg-[#A7C4E2] bg-opacity-10">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-semibold text-gray-800 mb-4">
              Transform Your Sleep Experience Today
            </h2>
            <p className="text-gray-600 mb-8">
              Join thousands of satisfied customers who have discovered the perfect balance of comfort, support, and luxury with Dorséa. Your journey to better sleep starts here.
            </p>
            <Link 
              to="/category/mattresses" 
              className="inline-block px-6 py-3 bg-[#A7C4E2] hover:bg-[#8CAFD6] text-white font-semibold rounded-md transition-colors duration-300"
            >
              Start Shopping
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;