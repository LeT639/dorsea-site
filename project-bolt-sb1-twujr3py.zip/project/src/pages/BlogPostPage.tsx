import React, { useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getBlogPost } from '../data/blogPosts';
import { ArrowLeft, Calendar, Clock, User } from 'lucide-react';

const BlogPostPage: React.FC = () => {
  const { postId } = useParams<{ postId: string }>();
  const post = postId ? getBlogPost(postId) : undefined;
  
  useEffect(() => {
    if (post) {
      // Scroll to top when post changes
      window.scrollTo(0, 0);
    }
  }, [post]);

  if (!post) {
    return <div className="container mx-auto px-4 py-16">Blog post not found</div>;
  }

  return (
    <div className="pt-24 pb-16">
      <article>
        {/* Hero Section */}
        <div className="w-full h-96 relative">
          <img 
            src={post.coverImage} 
            alt={post.title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent">
            <div className="container mx-auto px-4 h-full flex flex-col justify-end pb-12">
              <div className="max-w-3xl">
                <div className="flex items-center gap-2 mb-3">
                  <span className="px-3 py-1 bg-white text-gray-800 text-sm font-medium rounded-full">
                    {post.category}
                  </span>
                </div>
                <h1 className="text-3xl md:text-4xl lg:text-5xl font-semibold text-white mb-4">{post.title}</h1>
                <div className="flex flex-wrap items-center gap-4 text-white/80">
                  <div className="flex items-center gap-2">
                    <User size={16} />
                    <span>{post.author}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar size={16} />
                    <span>
                      {new Date(post.publishDate).toLocaleDateString('fr-FR', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock size={16} />
                    <span>{post.readTime} min read</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Content */}
        <div className="container mx-auto px-4 py-12">
          <div className="max-w-3xl mx-auto">
            <div className="prose prose-lg max-w-none" dangerouslySetInnerHTML={{ __html: post.content }}></div>
            
            {/* Author */}
            <div className="mt-12 pt-8 border-t border-gray-200">
              <div className="flex items-center">
                {post.authorImage && (
                  <img 
                    src={post.authorImage} 
                    alt={post.author} 
                    className="w-16 h-16 rounded-full object-cover mr-4"
                  />
                )}
                <div>
                  <p className="font-semibold text-gray-800">Written by {post.author}</p>
                  <p className="text-gray-600">Sleep Expert at Dorséa</p>
                </div>
              </div>
            </div>
            
            {/* Back to Blog */}
            <div className="mt-12">
              <Link 
                to="/blog" 
                className="flex items-center text-[#A7C4E2] hover:text-[#8CAFD6] transition-colors"
              >
                <ArrowLeft size={16} className="mr-2" />
                Back to Sleep Blog
              </Link>
            </div>
          </div>
        </div>
      </article>
    </div>
  );
};

export default BlogPostPage;