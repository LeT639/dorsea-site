import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Search, ShoppingBag, User, Menu, X } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { categories } from '../../data/categories';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { getCartCount } = useCart();
  const location = useLocation();
  
  const cartCount = getCartCount();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  return (
    <header 
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="text-3xl font-serif text-[#A7C4E2] font-bold">
            Dorséa
          </Link>

          <nav className="hidden md:block">
            <ul className="flex space-x-8">
              {categories.map((category) => (
                <li key={category.id}>
                  <Link 
                    to={`/category/${category.id}`} 
                    className="text-gray-700 hover:text-[#A7C4E2] transition-colors font-medium"
                  >
                    {category.name}
                  </Link>
                </li>
              ))}
              <li>
                <Link 
                  to="/blog" 
                  className="text-gray-700 hover:text-[#A7C4E2] transition-colors font-medium"
                >
                  Blog
                </Link>
              </li>
            </ul>
          </nav>

          <div className="flex items-center space-x-4">
            <button 
              className="text-gray-700 hover:text-[#A7C4E2] transition-colors"
              aria-label="Rechercher"
            >
              <Search size={20} />
            </button>
            <Link 
              to="/account" 
              className="text-gray-700 hover:text-[#A7C4E2] transition-colors"
              aria-label="Mon compte"
            >
              <User size={20} />
            </Link>
            <Link 
              to="/cart" 
              className="text-gray-700 hover:text-[#A7C4E2] transition-colors relative"
              aria-label="Panier"
            >
              <ShoppingBag size={20} />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-[#A7C4E2] text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Link>
            <button 
              className="md:hidden text-gray-700 hover:text-[#A7C4E2] transition-colors"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label={isMenuOpen ? "Fermer le menu" : "Ouvrir le menu"}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 absolute w-full left-0 shadow-lg py-4 px-6 animate-fade-down animate-duration-300">
          <nav>
            <ul className="space-y-4">
              {categories.map((category) => (
                <li key={category.id}>
                  <Link 
                    to={`/category/${category.id}`} 
                    className="text-gray-700 hover:text-[#A7C4E2] transition-colors font-medium block py-2"
                  >
                    {category.name}
                  </Link>
                </li>
              ))}
              <li>
                <Link 
                  to="/blog" 
                  className="text-gray-700 hover:text-[#A7C4E2] transition-colors font-medium block py-2"
                >
                  Blog
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;