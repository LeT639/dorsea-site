import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter, Mail, Phone, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#F5F2EA] pt-14 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <Link to="/" className="text-3xl font-serif text-[#A7C4E2] font-bold mb-4 block">
              Dorséa
            </Link>
            <p className="text-gray-600 mb-6">
              Premium bedding for a better night's sleep. Comfort, quality, and design for your bedroom sanctuary.
            </p>
            <div className="flex space-x-4">
              <a href="https://facebook.com" className="text-gray-500 hover:text-[#A7C4E2] transition-colors" aria-label="Facebook">
                <Facebook size={20} />
              </a>
              <a href="https://instagram.com" className="text-gray-500 hover:text-[#A7C4E2] transition-colors" aria-label="Instagram">
                <Instagram size={20} />
              </a>
              <a href="https://twitter.com" className="text-gray-500 hover:text-[#A7C4E2] transition-colors" aria-label="Twitter">
                <Twitter size={20} />
              </a>
            </div>
          </div>

          {/* Shop Links */}
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Shop</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/category/mattresses" className="text-gray-600 hover:text-[#A7C4E2] transition-colors">
                  Mattresses
                </Link>
              </li>
              <li>
                <Link to="/category/bed-frames" className="text-gray-600 hover:text-[#A7C4E2] transition-colors">
                  Bed Frames
                </Link>
              </li>
              <li>
                <Link to="/category/bed-linens" className="text-gray-600 hover:text-[#A7C4E2] transition-colors">
                  Bed Linens
                </Link>
              </li>
              <li>
                <Link to="/cart" className="text-gray-600 hover:text-[#A7C4E2] transition-colors">
                  Shopping Cart
                </Link>
              </li>
            </ul>
          </div>

          {/* Information */}
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Information</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/blog" className="text-gray-600 hover:text-[#A7C4E2] transition-colors">
                  Sleep Blog
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-600 hover:text-[#A7C4E2] transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/delivery" className="text-gray-600 hover:text-[#A7C4E2] transition-colors">
                  Delivery
                </Link>
              </li>
              <li>
                <Link to="/returns" className="text-gray-600 hover:text-[#A7C4E2] transition-colors">
                  Returns Policy
                </Link>
              </li>
              <li>
                <Link to="/terms" className="text-gray-600 hover:text-[#A7C4E2] transition-colors">
                  Terms & Conditions
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="text-gray-600 hover:text-[#A7C4E2] transition-colors">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start space-x-2">
                <MapPin size={18} className="text-[#A7C4E2] mt-1 flex-shrink-0" />
                <span className="text-gray-600">123 Sleep Street, 75001 Paris, France</span>
              </li>
              <li className="flex items-center space-x-2">
                <Phone size={18} className="text-[#A7C4E2] flex-shrink-0" />
                <a href="tel:+33123456789" className="text-gray-600 hover:text-[#A7C4E2] transition-colors">
                  +33 1 23 45 67 89
                </a>
              </li>
              <li className="flex items-center space-x-2">
                <Mail size={18} className="text-[#A7C4E2] flex-shrink-0" />
                <a href="mailto:contact@dorsea.com" className="text-gray-600 hover:text-[#A7C4E2] transition-colors">
                  contact@dorsea.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Payment Icons & Newsletter */}
        <div className="mt-12 pt-8 border-t border-gray-200">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            <div className="order-2 md:order-1">
              <div className="flex flex-wrap gap-3">
                <img src="https://cdn.simpleicons.org/visa/888888" alt="Visa" className="h-8 w-auto opacity-70" />
                <img src="https://cdn.simpleicons.org/mastercard/888888" alt="Mastercard" className="h-8 w-auto opacity-70" />
                <img src="https://cdn.simpleicons.org/paypal/888888" alt="PayPal" className="h-8 w-auto opacity-70" />
                <img src="https://cdn.simpleicons.org/applepay/888888" alt="Apple Pay" className="h-8 w-auto opacity-70" />
              </div>
            </div>
            <div className="order-1 md:order-2">
              <div className="flex flex-col sm:flex-row items-center gap-3">
                <label htmlFor="newsletter" className="text-gray-700 whitespace-nowrap">Join our newsletter:</label>
                <div className="flex w-full max-w-md">
                  <input
                    type="email"
                    id="newsletter"
                    placeholder="Your email address"
                    className="flex-grow px-4 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-[#A7C4E2] focus:border-transparent"
                  />
                  <button className="bg-[#A7C4E2] hover:bg-[#8CAFD6] transition-colors text-white px-4 py-2 rounded-r-md">
                    Subscribe
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-8 text-center text-gray-500 text-sm">
          <p>© {new Date().getFullYear()} Dorséa. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;