import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag } from 'lucide-react';
import { Product } from '../../types';
import { useCart } from '../../context/CartContext';

interface ProductCardProps {
  product: Product;
  featured?: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, featured = false }) => {
  const { addToCart } = useCart();
  
  const defaultVariant = product.variants.find(v => v.inStock) || product.variants[0];
  const hasDiscount = defaultVariant.originalPrice && defaultVariant.originalPrice > defaultVariant.price;
  const discountPercentage = hasDiscount 
    ? Math.round(((defaultVariant.originalPrice! - defaultVariant.price) / defaultVariant.originalPrice!) * 100) 
    : 0;

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    if (defaultVariant && defaultVariant.inStock) {
      addToCart(product, defaultVariant, 1);
    }
  };

  return (
    <div className={`group ${featured ? 'col-span-full md:col-span-1' : ''}`}>
      <Link to={`/product/${product.id}`} className="block relative overflow-hidden rounded-lg">
        <div className="aspect-square overflow-hidden bg-gray-100 rounded-lg">
          <img 
            src={product.images[0]} 
            alt={product.name} 
            className="w-full h-full object-cover object-center transform group-hover:scale-105 transition-transform duration-300"
          />
        </div>

        <div 
          className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          onClick={handleQuickAdd}
        >
          <button 
            className={`p-3 rounded-full shadow-md ${defaultVariant.inStock ? 'bg-[#A7C4E2] hover:bg-[#8CAFD6]' : 'bg-gray-300 cursor-not-allowed'} text-white`}
            disabled={!defaultVariant.inStock}
            aria-label="Ajouter au panier"
          >
            <ShoppingBag size={20} />
          </button>
        </div>

        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {product.isNew && (
            <span className="px-2 py-1 bg-[#A7C4E2] text-white text-xs font-semibold rounded">Nouveau</span>
          )}
          {product.isBestseller && (
            <span className="px-2 py-1 bg-[#F5F2EA] text-gray-700 text-xs font-semibold rounded">Bestseller</span>
          )}
          {hasDiscount && (
            <span className="px-2 py-1 bg-red-500 text-white text-xs font-semibold rounded">-{discountPercentage}%</span>
          )}
        </div>
      </Link>

      <div className="mt-4">
        <Link to={`/product/${product.id}`} className="block">
          <h3 className="text-lg font-medium text-gray-800 hover:text-[#A7C4E2] transition-colors">{product.name}</h3>
        </Link>
        <p className="text-sm text-gray-500 mt-1">{product.shortDescription}</p>
        
        <div className="mt-2 flex items-center">
          <span className="text-lg font-semibold">{defaultVariant.price.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}</span>
          {hasDiscount && (
            <span className="ml-2 text-sm text-gray-500 line-through">
              {defaultVariant.originalPrice!.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}
            </span>
          )}
        </div>
        
        <div className="mt-2 flex items-center">
          <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
              <svg 
                key={i}
                className={`w-4 h-4 ${i < Math.floor(product.rating) ? 'text-yellow-400' : 'text-gray-300'}`}
                fill="currentColor" 
                viewBox="0 0 20 20"
              >
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118l-2.799-2.034c-.784-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
            ))}
          </div>
          <span className="ml-1 text-sm text-gray-500">({product.reviewCount})</span>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;