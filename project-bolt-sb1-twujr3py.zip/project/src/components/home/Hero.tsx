import React from 'react';
import { Link } from 'react-router-dom';

const Hero: React.FC = () => {
  return (
    <div className="relative pt-16 pb-32 flex content-center items-center justify-center">
      <div className="absolute top-0 w-full h-full bg-center bg-cover" style={{
        backgroundImage: "url('https://images.pexels.com/photos/6186441/pexels-photo-6186441.jpeg')",
      }}>
        <span className="w-full h-full absolute opacity-30 bg-black"></span>
      </div>
      <div className="container relative mx-auto px-4">
        <div className="flex flex-wrap items-center">
          <div className="w-full lg:w-7/12 px-4 ml-auto mr-auto text-center">
            <div className="p-8 bg-white bg-opacity-90 rounded-lg shadow-lg max-w-2xl mx-auto" data-aos="fade-up">
              <h1 className="text-gray-800 font-semibold text-4xl md:text-5xl leading-tight mb-4">
                Transformez votre expérience de sommeil
              </h1>
              <p className="text-gray-600 text-lg mb-8">
                Matelas premium, sommiers et linge de lit conçus pour un confort exceptionnel. Fabriqués avec soin pour des nuits parfaites.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Link
                  to="/category/matelas"
                  className="px-6 py-3 bg-[#A7C4E2] hover:bg-[#8CAFD6] text-white font-semibold rounded-md transition-colors duration-300 shadow-md"
                >
                  Découvrir nos matelas
                </Link>
                <Link
                  to="/category/sommiers"
                  className="px-6 py-3 border border-[#A7C4E2] hover:bg-[#F5F2EA] text-[#A7C4E2] font-semibold rounded-md transition-colors duration-300"
                >
                  Explorer nos sommiers
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;