import React from 'react';
import { Shield, Clock, Truck, RotateCcw } from 'lucide-react';

interface Benefit {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const BenefitsSection: React.FC = () => {
  const benefits: Benefit[] = [
    {
      icon: <Shield className="h-10 w-10 text-[#A7C4E2]" />,
      title: "Garantie 10 ans",
      description: "Tous nos matelas sont garantis 10 ans contre les défauts de fabrication."
    },
    {
      icon: <Clock className="h-10 w-10 text-[#A7C4E2]" />,
      title: "Essai 100 nuits",
      description: "Testez nos produits pendant 100 nuits. Si vous n'êtes pas satisfait, nous organisons le retour."
    },
    {
      icon: <Truck className="h-10 w-10 text-[#A7C4E2]" />,
      title: "Livraison gratuite",
      description: "Livraison offerte pour toute commande supérieure à 500€ en France métropolitaine."
    },
    {
      icon: <RotateCcw className="h-10 w-10 text-[#A7C4E2]" />,
      title: "Retours faciles",
      description: "Retours simples et sans tracas si nos produits ne répondent pas à vos attentes."
    }
  ];

  return (
    <section className="py-16 bg-[#F5F2EA]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-semibold text-gray-800">Pourquoi choisir Dorséa</h2>
          <p className="mt-3 text-gray-600 max-w-2xl mx-auto">
            Nous nous engageons à vous offrir la meilleure expérience de sommeil grâce à des produits de qualité et un service exceptionnel.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {benefits.map((benefit, index) => (
            <div 
              key={index} 
              className="bg-white p-6 rounded-lg shadow-sm flex flex-col items-center text-center"
            >
              <div className="mb-4">
                {benefit.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">{benefit.title}</h3>
              <p className="text-gray-600">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BenefitsSection;