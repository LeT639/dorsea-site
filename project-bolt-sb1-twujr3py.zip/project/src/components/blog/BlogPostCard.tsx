import React from 'react';
import { Link } from 'react-router-dom';
import { BlogPost } from '../../types';
import { Clock } from 'lucide-react';

interface BlogPostCardProps {
  post: BlogPost;
  featured?: boolean;
}

const BlogPostCard: React.FC<BlogPostCardProps> = ({ post, featured = false }) => {
  return (
    <article className={`group overflow-hidden rounded-lg shadow-sm border border-gray-100 ${featured ? 'md:col-span-2 md:grid md:grid-cols-2 md:items-center' : ''}`}>
      <Link 
        to={`/blog/${post.id}`} 
        className={`block overflow-hidden ${featured ? 'md:h-full' : 'aspect-[16/9]'}`}
      >
        <img 
          src={post.coverImage} 
          alt={post.title} 
          className="w-full h-full object-cover object-center transform group-hover:scale-105 transition-transform duration-500"
        />
      </Link>
      
      <div className="p-6">
        <div className="flex items-center gap-2 mb-3">
          <span className="px-2 py-1 bg-[#F5F2EA] text-gray-700 text-xs font-medium rounded">
            {post.category}
          </span>
          <div className="flex items-center text-gray-500 text-sm">
            <Clock size={14} className="mr-1" />
            <span>{post.readTime} min read</span>
          </div>
        </div>
        
        <Link to={`/blog/${post.id}`}>
          <h3 className={`${featured ? 'text-2xl' : 'text-lg'} font-semibold text-gray-800 hover:text-[#A7C4E2] transition-colors mb-2 line-clamp-2`}>
            {post.title}
          </h3>
        </Link>
        
        <p className="text-gray-600 mb-4 line-clamp-3">
          {post.excerpt}
        </p>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            {post.authorImage && (
              <img 
                src={post.authorImage} 
                alt={post.author} 
                className="w-8 h-8 rounded-full object-cover mr-2"
              />
            )}
            <span className="text-sm text-gray-700">{post.author}</span>
          </div>
          
          <span className="text-sm text-gray-500">
            {new Date(post.publishDate).toLocaleDateString('fr-FR', {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            })}
          </span>
        </div>
      </div>
    </article>
  );
};

export default BlogPostCard;