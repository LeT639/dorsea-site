import { Product } from '../types';

export const products: Product[] = [
  {
    id: 'matelas-nuage-premium',
    name: 'Matelas Nuage Premium',
    slug: 'matelas-nuage-premium',
    category: 'matelas',
    subcategory: 'memoire-de-forme',
    description: `Le matelas Nuage Premium de Dorséa offre une expérience de sommeil incomparable grâce à sa mousse à mémoire de forme de haute densité. Doté de 5 zones de confort ergonomiques, il s'adapte parfaitement à votre morphologie pour un soutien optimal.

    La technologie de régulation thermique intégrée assure une température idéale toute la nuit, tandis que la housse hypoallergénique amovible et lavable garantit une hygiène parfaite.

    Fabriqué en France avec des matériaux de première qualité, ce matelas représente l'alliance parfaite entre confort, durabilité et innovation.`,
    shortDescription: 'Matelas haut de gamme à mémoire de forme avec 5 zones de confort et régulation thermique.',
    features: [
      '5 zones de confort ergonomiques',
      'Mousse à mémoire de forme haute densité (50 kg/m³)',
      'Régulation thermique avancée',
      'Housse hypoallergénique déhoussable',
      'Soutien ferme (7/10)',
      'Garantie 10 ans',
      'Fabriqué en France',
      'Essai 100 nuits satisfait ou remboursé'
    ],
    images: [
      'https://images.pexels.com/photos/6186812/pexels-photo-6186812.jpeg',
      'https://images.pexels.com/photos/6186813/pexels-photo-6186813.jpeg',
      'https://images.pexels.com/photos/6186814/pexels-photo-6186814.jpeg'
    ],
    variants: [
      {
        id: 'nuage-90x190',
        name: '90x190 cm',
        price: 599,
        originalPrice: 699,
        size: '90x190',
        inStock: true,
        sku: 'NUAGE-90190'
      },
      {
        id: 'nuage-140x190',
        name: '140x190 cm',
        price: 799,
        originalPrice: 899,
        size: '140x190',
        inStock: true,
        sku: 'NUAGE-140190'
      },
      {
        id: 'nuage-160x200',
        name: '160x200 cm',
        price: 899,
        originalPrice: 999,
        size: '160x200',
        inStock: true,
        sku: 'NUAGE-160200'
      },
      {
        id: 'nuage-180x200',
        name: '180x200 cm',
        price: 999,
        originalPrice: 1199,
        size: '180x200',
        inStock: false,
        sku: 'NUAGE-180200'
      }
    ],
    rating: 4.8,
    reviewCount: 324,
    isNew: false,
    isBestseller: true,
    isOnSale: true
  },
  {
    id: 'matelas-elysee-hybrid',
    name: 'Matelas Élysée Hybrid',
    slug: 'matelas-elysee-hybrid',
    category: 'matelas',
    subcategory: 'hybride',
    description: `Le matelas Élysée Hybrid combine le meilleur des technologies de sommeil modernes. Son système hybride associe des ressorts ensachés à 7 zones avec une couche de mousse à mémoire de forme premium.

    Les 1000+ ressorts ensachés assurent une indépendance de couchage parfaite et un soutien point par point, tandis que la mousse à mémoire épouse vos formes pour un confort enveloppant.

    La housse en coton bio respirante et le système de ventilation avancé garantissent une régulation optimale de la température.`,
    shortDescription: 'Matelas hybride premium combinant ressorts ensachés et mousse à mémoire de forme.',
    features: [
      'Système hybride ressorts + mousse mémoire',
      '7 zones de confort',
      '1000+ ressorts ensachés',
      'Housse en coton bio',
      'Soutien medium-ferme (6/10)',
      'Garantie 10 ans',
      'Fabriqué en France',
      'Essai 100 nuits satisfait ou remboursé'
    ],
    images: [
      'https://images.pexels.com/photos/5715872/pexels-photo-5715872.jpeg',
      'https://images.pexels.com/photos/5715873/pexels-photo-5715873.jpeg',
      'https://images.pexels.com/photos/5715874/pexels-photo-5715874.jpeg'
    ],
    variants: [
      {
        id: 'elysee-90x190',
        name: '90x190 cm',
        price: 799,
        originalPrice: 899,
        size: '90x190',
        inStock: true,
        sku: 'ELYSEE-90190'
      },
      {
        id: 'elysee-140x190',
        name: '140x190 cm',
        price: 999,
        originalPrice: 1199,
        size: '140x190',
        inStock: true,
        sku: 'ELYSEE-140190'
      },
      {
        id: 'elysee-160x200',
        name: '160x200 cm',
        price: 1199,
        originalPrice: 1399,
        size: '160x200',
        inStock: true,
        sku: 'ELYSEE-160200'
      },
      {
        id: 'elysee-180x200',
        name: '180x200 cm',
        price: 1399,
        originalPrice: 1599,
        size: '180x200',
        inStock: true,
        sku: 'ELYSEE-180200'
      }
    ],
    rating: 4.9,
    reviewCount: 216,
    isNew: true,
    isBestseller: false,
    isOnSale: true
  },
  {
    id: 'sommier-opera-premium',
    name: 'Sommier Opéra Premium',
    slug: 'sommier-opera-premium',
    category: 'sommiers',
    subcategory: 'tapissier',
    description: `Le sommier Opéra Premium allie élégance et fonctionnalité. Sa structure en bois massif et ses lattes multiplis garantissent une durabilité exceptionnelle et un soutien optimal pour votre matelas.

    La tête de lit capitonnée, habillée d'un tissu premium aspect lin, apporte une touche de raffinement à votre chambre. Les deux tiroirs de rangement intégrés offrent une solution pratique pour optimiser l'espace.

    Disponible en plusieurs coloris, il s'adapte parfaitement à tous les styles d'intérieur.`,
    shortDescription: 'Sommier tapissier haut de gamme avec tête de lit capitonnée et rangements intégrés.',
    features: [
      'Structure en bois massif',
      'Lattes multiplis renforcées',
      'Tête de lit capitonnée',
      '2 tiroirs de rangement',
      'Tissu premium aspect lin',
      'Pieds en bois massif',
      'Garantie 5 ans',
      'Montage facile'
    ],
    images: [
      'https://images.pexels.com/photos/1743229/pexels-photo-1743229.jpeg',
      'https://images.pexels.com/photos/1743230/pexels-photo-1743230.jpeg',
      'https://images.pexels.com/photos/1743231/pexels-photo-1743231.jpeg'
    ],
    variants: [
      {
        id: 'opera-140-beige',
        name: '140x190 cm - Beige',
        price: 799,
        originalPrice: 899,
        size: '140x190',
        color: 'Beige',
        inStock: true,
        sku: 'OPERA-140-BEIGE'
      },
      {
        id: 'opera-140-gris',
        name: '140x190 cm - Gris',
        price: 799,
        originalPrice: 899,
        size: '140x190',
        color: 'Gris',
        inStock: true,
        sku: 'OPERA-140-GRIS'
      },
      {
        id: 'opera-160-beige',
        name: '160x200 cm - Beige',
        price: 899,
        originalPrice: 999,
        size: '160x200',
        color: 'Beige',
        inStock: true,
        sku: 'OPERA-160-BEIGE'
      },
      {
        id: 'opera-160-gris',
        name: '160x200 cm - Gris',
        price: 899,
        originalPrice: 999,
        size: '160x200',
        color: 'Gris',
        inStock: false,
        sku: 'OPERA-160-GRIS'
      }
    ],
    rating: 4.7,
    reviewCount: 153,
    isNew: false,
    isBestseller: true,
    isOnSale: true
  },
  {
    id: 'parure-riviera-coton-bio',
    name: 'Parure Riviera en Coton Bio',
    slug: 'parure-riviera-coton-bio',
    category: 'linge-de-lit',
    subcategory: 'parures',
    description: `La parure Riviera en coton bio certifié GOTS vous offre un confort de sommeil exceptionnel. Avec ses 200 fils/cm², ce linge de lit combine douceur, respirabilité et durabilité.

    Le tissage satiné confère un aspect légèrement brillant et une sensation soyeuse au toucher. Les finitions soignées et les coins capuchons assurent un maintien parfait.

    Chaque parure comprend une housse de couette et deux taies d'oreiller assorties.`,
    shortDescription: 'Parure de lit haut de gamme en coton bio 200 fils/cm² avec finition satinée.',
    features: [
      'Coton bio certifié GOTS',
      '200 fils/cm²',
      'Tissage satiné',
      'Coins capuchons',
      'Lavable en machine à 60°C',
      'Garantie 2 ans',
      'Fabrication éthique',
      'Certifié Oeko-Tex®'
    ],
    images: [
      'https://images.pexels.com/photos/6186566/pexels-photo-6186566.jpeg',
      'https://images.pexels.com/photos/6186567/pexels-photo-6186567.jpeg',
      'https://images.pexels.com/photos/6186568/pexels-photo-6186568.jpeg'
    ],
    variants: [
      {
        id: 'riviera-140-blanc',
        name: '140x200 cm - Blanc',
        price: 129,
        originalPrice: 149,
        size: '140x200',
        color: 'Blanc',
        inStock: true,
        sku: 'RIVIERA-140-BLANC'
      },
      {
        id: 'riviera-140-beige',
        name: '140x200 cm - Beige',
        price: 129,
        originalPrice: 149,
        size: '140x200',
        color: 'Beige',
        inStock: true,
        sku: 'RIVIERA-140-BEIGE'
      },
      {
        id: 'riviera-160-blanc',
        name: '160x200 cm - Blanc',
        price: 149,
        originalPrice: 169,
        size: '160x200',
        color: 'Blanc',
        inStock: true,
        sku: 'RIVIERA-160-BLANC'
      },
      {
        id: 'riviera-160-beige',
        name: '160x200 cm - Beige',
        price: 149,
        originalPrice: 169,
        size: '160x200',
        color: 'Beige',
        inStock: true,
        sku: 'RIVIERA-160-BEIGE'
      }
    ],
    rating: 4.8,
    reviewCount: 214,
    isNew: false,
    isBestseller: true,
    isOnSale: true
  }
];

export const getProduct = (id: string): Product | undefined => {
  return products.find(product => product.id === id);
};

export const getProductBySlug = (slug: string): Product | undefined => {
  return products.find(product => product.slug === slug);
};

export const getProductsByCategory = (category: string): Product[] => {
  return products.filter(product => product.category === category);
};

export const getNewProducts = (): Product[] => {
  return products.filter(product => product.isNew);
};

export const getBestsellerProducts = (): Product[] => {
  return products.filter(product => product.isBestseller);
};

export const getOnSaleProducts = (): Product[] => {
  return products.filter(product => product.isOnSale);
};