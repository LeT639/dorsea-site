import { Testimonial } from '../types';

export const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Sophie Martin',
    rating: 5,
    text: 'The Nuage mattress has completely transformed my sleep. I used to wake up with back pain every morning, but now I wake up feeling refreshed and pain-free. The memory foam perfectly contours to my body, providing just the right amount of support. Definitely worth the investment!',
    product: 'Nuage Premium Memory Foam Mattress',
    date: '2025-03-15'
  },
  {
    id: '2',
    name: 'Thomas Dubois',
    rating: 5,
    text: 'We\'ve had our Élysée Hybrid Mattress for about 3 months now and couldn\'t be happier. The combination of springs and memory foam offers the perfect balance of support and comfort. My wife and I have different preferences for mattress firmness, but this one somehow works perfectly for both of us!',
    product: 'Élysée Hybrid Mattress',
    date: '2025-02-28'
  },
  {
    id: '3',
    name: 'Emma Leroy',
    rating: 4,
    text: 'The Riviera sheet set is absolutely luxurious! The organic cotton is incredibly soft, and the sheets get even better after washing. I also appreciate that they\'re eco-friendly. The only reason for 4 stars instead of 5 is that I wish they came in more color options.',
    product: 'Riviera Organic Cotton Sheet Set',
    date: '2025-03-10'
  },
  {
    id: '4',
    name: 'Lucas Bernard',
    rating: 5,
    text: 'The Opéra bed frame is not only beautiful but also extremely sturdy. The storage drawers are a game-changer for our small apartment. Assembly was straightforward, and the quality exceeds what I expected for the price. Highly recommend!',
    product: 'Opéra Premium Bed Frame',
    date: '2025-03-05'
  }
];