import { Category } from '../types';

export const categories: Category[] = [
  {
    id: 'matelas',
    name: 'Matelas',
    slug: 'matelas',
    description: 'Découvrez notre gamme de matelas premium alliant confort et soutien. Des solutions adaptées à tous les types de dormeurs.',
    image: 'https://images.pexels.com/photos/6186811/pexels-photo-6186811.jpeg',
    featuredProducts: ['1', '2']
  },
  {
    id: 'sommiers',
    name: 'Sommiers',
    slug: 'sommiers',
    description: 'Sublimez votre chambre avec nos sommiers élégants et robustes. Choisissez parmi nos modèles tapissés, cadres en bois et solutions de rangement.',
    image: 'https://images.pexels.com/photos/1743229/pexels-photo-1743229.jpeg',
    featuredProducts: ['3']
  },
  {
    id: 'linge-de-lit',
    name: 'Linge de lit',
    slug: 'linge-de-lit',
    description: 'Transformez votre expérience de sommeil avec notre linge de lit premium. Des matériaux nobles pour un confort absolu.',
    image: 'https://images.pexels.com/photos/6186566/pexels-photo-6186566.jpeg',
    featuredProducts: ['4']
  }
];

export const getCategory = (id: string): Category | undefined => {
  return categories.find(category => category.id === id);
};

export const getCategoryBySlug = (slug: string): Category | undefined => {
  return categories.find(category => category.slug === slug);
};