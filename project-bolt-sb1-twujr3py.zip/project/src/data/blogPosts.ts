import { BlogPost } from '../types';

export const blogPosts: BlogPost[] = [
  {
    id: '1',
    title: 'The Science of Sleep: How Your Mattress Affects Your Health',
    slug: 'science-of-sleep-mattress-affects-health',
    excerpt: 'Discover how your mattress choice directly impacts your sleep quality and overall health, from spine alignment to sleep temperature.',
    content: `
      <h2>The Science of Sleep: How Your Mattress Affects Your Health</h2>
      
      <p>Sleep is essential for our physical and mental wellbeing, and the mattress we sleep on plays a crucial role in determining the quality of our rest. Research has shown that a supportive mattress can significantly improve sleep quality, reduce pain, and enhance overall health.</p>
      
      <h3>Spinal Alignment and Pain Reduction</h3>
      
      <p>One of the primary functions of a mattress is to maintain proper spinal alignment during sleep. When your spine is properly aligned, pressure points are reduced, and your muscles can fully relax. This is particularly important for people who suffer from back pain, as the right mattress can provide relief and prevent further issues.</p>
      
      <p>Memory foam mattresses, like our Nuage Premium model, are designed to contour to your body's shape, providing targeted support where it's needed most. This helps maintain natural spinal alignment regardless of your sleeping position.</p>
      
      <h3>Sleep Temperature Regulation</h3>
      
      <p>Body temperature plays a significant role in sleep quality. Research indicates that a slight drop in core body temperature helps initiate and maintain sleep. Some mattresses can trap heat, causing discomfort and disrupting sleep cycles.</p>
      
      <p>Modern mattresses like our Élysée Hybrid incorporate cooling technologies such as breathable covers, gel-infused memory foam, and airflow-promoting designs to help regulate temperature throughout the night.</p>
      
      <h3>Allergies and Respiratory Health</h3>
      
      <p>Traditional mattresses can harbor dust mites, mold, and other allergens that may trigger allergic reactions and respiratory issues. Hypoallergenic mattresses and those with removable, washable covers can significantly reduce these problems.</p>
      
      <h3>Motion Isolation for Couples</h3>
      
      <p>For couples, motion isolation is a key factor in sleep quality. When one person changes position or gets in and out of bed, the disturbance can wake their partner. Mattresses with good motion isolation, particularly those with memory foam or individually wrapped coils, minimize this transfer of movement.</p>
      
      <h3>Mattress Lifespan and Replacement</h3>
      
      <p>Even the highest quality mattresses don't last forever. Over time, mattresses lose their supportive properties and can develop sags and indentations. Most experts recommend replacing your mattress every 7-10 years, depending on the type and quality.</p>
      
      <p>Signs that it's time for a new mattress include visible sagging, waking up with pain or stiffness, sleeping better in other beds, or noticeable wear and tear.</p>
      
      <h3>Conclusion</h3>
      
      <p>Your mattress is more than just a piece of furniture—it's a critical component of your health and wellbeing. Investing in a quality mattress that suits your specific needs can lead to better sleep, reduced pain, and improved overall health.</p>
      
      <p>At Dorséa, we're committed to helping you find the perfect mattress for your needs. Our sleep experts are available to guide you through the selection process, ensuring you make the choice that's right for your body and sleep preferences.</p>
    `,
    coverImage: 'https://images.pexels.com/photos/5469889/pexels-photo-5469889.jpeg',
    category: 'Sleep Health',
    author: 'Dr. Claire Moreau',
    authorImage: 'https://images.pexels.com/photos/5721868/pexels-photo-5721868.jpeg',
    publishDate: '2025-03-10',
    readTime: 6
  },
  {
    id: '2',
    title: '5 Tips for Extending the Life of Your Mattress',
    slug: '5-tips-extending-life-of-your-mattress',
    excerpt: 'Learn practical strategies to maintain your mattress in optimal condition and extend its lifespan for years of comfortable sleep.',
    content: `
      <h2>5 Tips for Extending the Life of Your Mattress</h2>
      
      <p>A quality mattress is a significant investment in your sleep health. With proper care and maintenance, you can extend the life of your mattress and ensure it provides comfortable, supportive sleep for many years. Here are five essential tips to help you maximize the lifespan of your mattress.</p>
      
      <h3>1. Use a Mattress Protector</h3>
      
      <p>A waterproof mattress protector is perhaps the most important accessory for extending mattress life. It creates a barrier against spills, stains, sweat, and body oils that can seep into your mattress and degrade the materials over time. A good protector also helps prevent dust mites and allergens from accumulating within your mattress.</p>
      
      <p>Look for breathable, waterproof protectors that won't change the feel of your mattress or make noise when you move. Our Dorséa Premium Mattress Protector offers excellent protection while maintaining the comfort of your mattress.</p>
      
      <h3>2. Rotate Your Mattress Regularly</h3>
      
      <p>Even with the most advanced materials, sleeping in the same spot night after night can cause uneven wear. Rotating your mattress 180 degrees every 3-6 months helps distribute this wear more evenly.</p>
      
      <p>Note that while older mattresses often needed to be flipped as well as rotated, most modern mattresses (particularly those with pillow tops or designated comfort layers) are one-sided and should only be rotated, not flipped.</p>
      
      <h3>3. Provide Proper Support</h3>
      
      <p>Your mattress needs proper support from a quality bed frame or foundation. An inadequate support system can cause your mattress to sag prematurely.</p>
      
      <p>Check your bed frame periodically for loose components or broken slats. For queen and king-sized mattresses, a center support bar is essential to prevent sagging in the middle.</p>
      
      <h3>4. Keep It Clean</h3>
      
      <p>Regular cleaning helps prevent the buildup of dust, allergens, and odors. Here's a simple cleaning routine:</p>
      
      <ul>
        <li>Vacuum your mattress every 1-3 months using the upholstery attachment</li>
        <li>Spot clean stains immediately with mild detergent and cold water</li>
        <li>Deodorize with baking soda: sprinkle a thin layer over the mattress, let it sit for a few hours, then vacuum it up</li>
      </ul>
      
      <p>Always check your mattress's care instructions before cleaning, as some materials may require special treatment.</p>
      
      <h3>5. Be Mindful of Usage Habits</h3>
      
      <p>Certain activities can damage your mattress and should be avoided:</p>
      
      <ul>
        <li>Don't sit on the edge of the bed repeatedly in the same spot</li>
        <li>Avoid jumping on the mattress</li>
        <li>Don't eat or drink in bed to prevent spills and crumbs</li>
        <li>Remove sharp objects (jewelry, belt buckles) before getting into bed</li>
        <li>If working from bed, alternate positions to avoid creating indentations</li>
      </ul>
      
      <h3>Bonus Tip: Follow Manufacturer Guidelines</h3>
      
      <p>Always follow the specific care instructions provided by your mattress manufacturer. These guidelines are designed to help you maintain your mattress according to its unique materials and construction.</p>
      
      <h3>When to Replace Your Mattress</h3>
      
      <p>Even with excellent care, all mattresses eventually need replacement. Signs that it's time include:</p>
      
      <ul>
        <li>Visible sagging or indentations deeper than 1-2 cm</li>
        <li>Waking up with pain or stiffness</li>
        <li>Feeling like you roll toward the center or edges</li>
        <li>Noticing increased allergy symptoms</li>
        <li>Sleeping better in other beds than your own</li>
      </ul>
      
      <p>By following these care tips, you can ensure your Dorséa mattress remains comfortable and supportive for its full expected lifespan, giving you years of restful sleep.</p>
    `,
    coverImage: 'https://images.pexels.com/photos/6186675/pexels-photo-6186675.jpeg',
    category: 'Maintenance',
    author: 'Marcel Dupont',
    authorImage: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg',
    publishDate: '2025-02-25',
    readTime: 4
  },
  {
    id: '3',
    title: 'Creating a Sleep Sanctuary: Bedroom Design Tips for Better Rest',
    slug: 'creating-sleep-sanctuary-bedroom-design-tips',
    excerpt: 'Transform your bedroom into a tranquil retreat that promotes restful sleep with these expert design and decor recommendations.',
    content: `
      <h2>Creating a Sleep Sanctuary: Bedroom Design Tips for Better Rest</h2>
      
      <p>Your bedroom environment plays a crucial role in the quality of your sleep. Beyond having a comfortable mattress and pillows, the overall design and atmosphere of your bedroom can significantly impact how quickly you fall asleep and how restfully you sleep through the night. Here's how to transform your bedroom into a true sleep sanctuary.</p>
      
      <h3>The Perfect Color Palette</h3>
      
      <p>Colors have a psychological impact on our mood and state of mind. For optimal sleep, consider these color strategies:</p>
      
      <ul>
        <li><strong>Cool tones</strong> like soft blues, gentle greens, and lavenders promote relaxation and have been shown to lower blood pressure and heart rate.</li>
        <li><strong>Neutral shades</strong> such as beiges, warm whites, and light grays create a timeless, calming atmosphere.</li>
        <li><strong>Avoid bright, stimulating colors</strong> like vivid reds, oranges, and neons, which can increase energy and alertness—exactly what you don't want at bedtime.</li>
      </ul>
      
      <p>Our Dorséa design experts recommend a palette of soft beige, warm white, and pale blue—mirroring our brand colors—for the ultimate sleep-promoting bedroom.</p>
      
      <h3>Lighting for Better Sleep</h3>
      
      <p>Proper lighting helps regulate your circadian rhythm, signaling to your body when it's time to sleep and when it's time to wake.</p>
      
      <ul>
        <li><strong>Layer your lighting</strong> with a combination of ambient, task, and accent lights to adjust brightness levels throughout the day.</li>
        <li><strong>Install dimmer switches</strong> to gradually reduce light intensity as bedtime approaches.</li>
        <li><strong>Choose warm-toned bulbs</strong> (2700-3000K) rather than cool white or daylight bulbs, which contain blue light that can suppress melatonin production.</li>
        <li><strong>Add blackout curtains or blinds</strong> to eliminate disruptive outside light during sleep hours.</li>
      </ul>
      
      <h3>Declutter for Calm</h3>
      
      <p>A cluttered bedroom creates a cluttered mind. Research shows that people sleep better in neat, organized spaces:</p>
      
      <ul>
        <li>Remove work-related items, exercise equipment, and electronic devices</li>
        <li>Hide storage under the bed or in attractive containers</li>
        <li>Keep surfaces clear, with minimal decorative items</li>
        <li>Consider a minimalist approach to furniture—include only what you truly need</li>
      </ul>
      
      <h3>Textiles and Textures</h3>
      
      <p>The fabrics in your bedroom add both comfort and sensory appeal:</p>
      
      <ul>
        <li><strong>Choose breathable, natural materials</strong> like cotton, linen, and bamboo for bedding</li>
        <li><strong>Layer textures</strong> with a mix of smooth sheets, plush duvets, and soft throws</li>
        <li><strong>Add an area rug</strong> to absorb sound and provide warmth underfoot</li>
        <li><strong>Consider window treatments</strong> that are both functional (blocking light) and beautiful</li>
      </ul>
      
      <p>Our Riviera bedding collection offers the perfect starting point, with organic cotton sheets that become softer with every wash.</p>
      
      <h3>Aromatherapy and Air Quality</h3>
      
      <p>Scent strongly influences mood and can prepare your mind and body for sleep:</p>
      
      <ul>
        <li>Lavender, chamomile, and cedarwood are particularly effective for promoting relaxation</li>
        <li>Use essential oil diffusers, linen sprays, or scented candles (extinguish before sleeping)</li>
        <li>Ensure good ventilation to maintain oxygen levels</li>
        <li>Consider an air purifier to reduce allergens</li>
      </ul>
      
      <h3>Technology and Sleep</h3>
      
      <p>Creating a true sleep sanctuary means addressing the impact of technology:</p>
      
      <ul>
        <li>Establish a "device-free zone" policy for the bedroom</li>
        <li>If you must have electronics, use blue light filters or night mode after sunset</li>
        <li>Keep TVs out of the bedroom if possible</li>
        <li>Consider analog alternatives for alarms and reading</li>
      </ul>
      
      <h3>Final Touches</h3>
      
      <p>These final elements can elevate your sleep sanctuary:</p>
      
      <ul>
        <li>A few plants to improve air quality and add life (snake plants, lavender, and aloe are good bedroom choices)</li>
        <li>Meaningful but calming artwork</li>
        <li>A white noise machine if external sounds are disruptive</li>
        <li>A dedicated relaxation corner with a comfortable chair for reading</li>
      </ul>
      
      <p>Remember that your bedroom should feel like a retreat from the world—a place dedicated to rest and rejuvenation. By thoughtfully designing this space with sleep in mind, you can significantly improve both the quality of your sleep and your overall wellbeing.</p>
    `,
    coverImage: 'https://images.pexels.com/photos/1743229/pexels-photo-1743229.jpeg',
    category: 'Interior Design',
    author: 'Amelia Rousseau',
    authorImage: 'https://images.pexels.com/photos/762020/pexels-photo-762020.jpeg',
    publishDate: '2025-03-05',
    readTime: 5
  }
];

export const getBlogPost = (id: string): BlogPost | undefined => {
  return blogPosts.find(post => post.id === id);
};

export const getBlogPostBySlug = (slug: string): BlogPost | undefined => {
  return blogPosts.find(post => post.slug === slug);
};

export const getBlogPostsByCategory = (category: string): BlogPost[] => {
  return blogPosts.filter(post => post.category === category);
};